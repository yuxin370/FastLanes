# 固定 checkpoint 存储基线后续任务

本清单按用户最新范围修订。详细问题、证据与影响条件见同包完整报告。产品代码尚未应用这些建议。

### 任务 A 冻结正确实验范围

目标：把默认实验明确为已有 checkpoint、同一 JPEG q/Q、同一完整输入语义的 storage-adapted baseline。保留 IC-native prepare 为可选研究入口，不让 N2–N4 阻塞主实验。

验收：每个结果声明 checkpoint 实际权重身份、profile、源内容身份、trace、backend 存储配置、源码/二进制身份及实验类型。说明哪些步骤共用，哪些是融合实现。已有历史脚本和数据格式继续保留；不要把旧 A0/B6 结果自动升级为 matched。

### 任务 B 修复窄范围 native 正确性与计量

修改 completion planner 的 descriptor→request_index 分组；给 split-source used/capacity/device metadata 接入既有 transient tracker。先使用本包确定性反例，随后新增或扩展同一 streamed-projection 路径的定向 GPU 验证；验证该分支时不能通过关闭分批模式获得通过，既有 --verify 的其他用途可以保留。

验收：反序、重复、多 workset、多输出批的实际输出和 ready/finalize 时序正确；所有未完成 writer 都在 finalize/event 之前。GPU 回归覆盖第二 consumer stream、立即复用 reader；资源总量包含新增缓冲，预算与公开字段一致。对当前零包含 clamp 先验收主线，P3 API 边缘项可随后处理。

### 任务 C 完成预训练 checkpoint 的推理等价验证

复用既有模型和推理入口，真正加载声明的预训练权重；记录实际加载后 state_dict 身份，禁止静默 reset 或 fallback。使用原有 validation crop/resize/normalization 与相同样本请求，覆盖预定模型 profile，至少包含 projected CNN 与非 projected Transformer 两条执行分支；主表涉及的 profile 都需要对应证据。

验收：相同 q/Q、标签、顺序、最终模型 tensor、logits/预测与任务指标；容差按既有数值语义预先声明，不能看到误差后放宽。先在正式微批/大 preparation batch 和 tail 上做定向 gate，再跑论文实际 inference 数据集。训练 G3 保留为训练实验需要时的补充，不再替代本任务。

### 任务 D 做共同后处理的存储对照并绑定当前源

复用现有公共后处理算子，给各 reader 建立最小系数交接；统一语义和 device 边界，每条路径为到达交接边界发生的 packing、dtype/layout 转换、同步和 H2D 均计入成本。FastLens 正式融合路径另行保留。正式启动关联现有 G1/common-source 内容绑定；更换同一路径 JPEG 的反例必须被拒绝或触发重验。

验收：common materializer 的算子与输入契约相同；明确交接前后的计时范围。存储体积计入索引/表等必需数据；同时输出请求 q 数、实际解压 q 数、应用读取字节与可观测物理 I/O。没有实测页缓存状态时使用明确的未测标签。

### 任务 E 冻结版本并测实际部署性能

基于最终源码和二进制运行正式推理 pipeline。对线程、group、cache/prefetch 做小预算调优，冻结后再报告；按相同全局 CPU 核心、GPU、内存、缓存状态和样本集合比较。共同后处理对照与各系统实际优化 E2E 分开报告。

验收：真实稳态吞吐、延迟分布、输入准备与 H2D/模型阶段、存储体积、CPU 时间、全局内存与 GPU transient/capacity；预取即使未消费也纳入成本或单列。记录 cache 状态与预校验成本。受 down2 变更影响的配置重测数值与性能；未经过该分支的历史实验不因文件改动而自动要求全部重训。
