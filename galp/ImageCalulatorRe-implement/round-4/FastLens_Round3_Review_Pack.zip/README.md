# FastLens 第三版审查复核包

本包服务于固定预训练 checkpoint 的 IC/FS 存储适配实验审查。完整结论在 FastLens_Round3_Review_and_Matched_Storage_Plan.md，最小后续任务在 AGENT_TASKS.md。

## 包含的内容

- 完整中文审查报告与 agent 任务清单。
- probes_storage：执行提交的原始 NumPy 存储模块，覆盖内容重写拒绝、解压数组生命周期、crop/部分频率/重复/乱序、cache budget 和 N1 prepare。
- probes_cuda：从提交源码提取实际 C++ planner/completion 函数，执行调度 oracle 与 CPU FP32/std::fma 代数探针；不是完整产品构建，也不运行 CUDA。
- probes_integration：执行原始纯 Python 配对/window helper 与 NumPy 源身份反例；不运行 Torch、训练或实际 GPU inference。
- probes_integrity：核对提交的 JSON、当前源码、manifest、trace、哈希引用与证据边界，不把缺失的二进制/图片/NPZ 当作已验证。
- observed_results：此次已经执行的结果与 CUDA 编译/运行日志。新执行不会改写这些历史结果。
- SOURCE_SHA256.json：附件中当前与基准源码的身份索引。

## 复现

需要本次原始 dct-round3-review.zip。SHA256 为：

e1a008b267261ebf562225c43baec7c028f890793bceb2bd98b2a9f6052e6cc6

在本包新的解压目录执行：

```bash
python3 prepare_submission.py /absolute/path/to/dct-round3-review.zip
python3 probes_storage/probe_round3.py
python3 probes_integration/probe_integration.py
python3 probes_cuda/run_probes.py
python3 probes_integrity/audit_round3.py
```

路径参数请替换为原始附件的实际绝对路径。准备脚本核对原始 ZIP 的哈希，验证成员路径与符号链接，拒绝覆盖已有 submission。

依赖为 Python3、NumPy、Pillow、支持 C++20 的 c++ 编译器；完整审查脚本不需要 Torch/CUDA。各 probe 从相邻 submission/current_repo 加载原始代码，只写自身目录的临时 fixture 或结果。测试使用的 common.sha256_file 缺失 helper 由普通 SHA256 实现补齐；不替换被审查的 reader、变换或训练行为。integration 的 check_pair 测试使用构造的身份 fixture，不宣称完整 training_identity 生成已被执行。

存储与 integration 探针会构建新 fixture，重复执行请使用新的解压目录。不要把负例生成的 store 当作论文实验数据。本包不是 FastLens 完整 build artifact，也没有原始8194张图片、8755个 NPZ payload、训练 snapshot 或所录 GPU 二进制，无法单靠此包复现 H100 数值 gate 或性能。

## 对 agent 的使用要求

先阅读报告的比较范围与问题影响条件，再处理任务清单。最近 down2 修复方向合理；完成映射问题在 base_HEAD 中已存在，正式 PLS 与本次 ViT gate 没有启用它。完整 IC-native 搜索是可选研究扩展，不能成为固定 checkpoint 存储实验的主线阻塞。

当前产品源码在这次审查中没有修改。本包不包含建议修复的产品补丁，也没有新的 GPU 或吞吐结果。
