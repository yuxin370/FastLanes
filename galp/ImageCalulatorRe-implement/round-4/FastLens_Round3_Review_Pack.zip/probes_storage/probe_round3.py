"""Independent Round-3 storage/N1 review. Product code is read-only.

The Round-2 regression definitions are executed unchanged except SOURCE points
to this submission. Only the absent galp.benchmarks.common.sha256_file helper
is provided; there is no Torch or transform emulation.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
from dataclasses import asdict
import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "submission/current_repo/galp/benchmarks/dct_baselines"
PREVIOUS = HERE / "round2_probe_definitions.py"
previous_text = PREVIOUS.read_text().split('\nresults = dict(scope=', 1)[0]
previous_text = previous_text.replace(
    'SOURCE = HERE.parent / "reconstructed/galp/benchmarks/dct_baselines"',
    'SOURCE = HERE.parent / "submission/current_repo/galp/benchmarks/dct_baselines"')
scope = {"__file__": str(HERE / "round2_definitions_at_round3.py"), "__name__": "round2_regression"}
exec(compile(previous_text, str(PREVIOUS), "exec"), scope)
store, contracts = scope["store"], scope["contracts"]


def cache_only():
    root = HERE / "artifacts/cache_only_fixed"
    sources = [scope["image"](0, components=1)]
    manifest = store.build_store(sources, root, "ic_matched_shared")
    member = next(iter(manifest["files"].values()))["decoded_bytes"]
    request = contracts.ReadRequest("0", (tuple(range(64)),))
    with store.StoreReader(root, cache_bytes=member, decode_budget_bytes=member,
                           memory_budget_bytes=4*member) as reader:
        first, cold = reader.read(reader.plan([request]))
        reader.memory_budget_bytes = member + cold.output_peak_bytes
        second, warm = reader.read(reader.plan([request]))
        scope["exact"](second, sources)
        assert warm.file_opens == warm.decoded_q_bytes == warm.active_decoded_peak_bytes == 0
        assert warm.reader_memory_peak_bytes == reader.memory_budget_bytes
        assert warm.decoded_cache_peak_bytes == member
        try:
            reader.read(reader.plan([request, request]))
        except MemoryError:
            overflowing_output_rejected = True
        else:
            raise AssertionError("cache/output budget overflow accepted")
        reader.cache.clear()
        reader.cache_size = 0
        try:
            reader.read(reader.plan([request]))
        except MemoryError:
            insufficient_cold_decode_rejected = True
        else:
            raise AssertionError("cold decode admitted without reserved capacity")
        return dict(member_bytes=member, exact_budget_bytes=reader.memory_budget_bytes,
                    warm=asdict(warm), overflowing_output_rejected=overflowing_output_rejected,
                    insufficient_cold_decode_rejected=insufficient_cold_decode_rejected)


def prepare_native():
    for basename in ("native", "native_search"):
        name = f"review_storage.{basename}"
        spec = importlib.util.spec_from_file_location(name, SOURCE / f"{basename}.py")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    search = sys.modules["review_storage.native_search"]
    rows = search.subset96()
    assert rows == search.subset96()
    pairs = {(r["spec"]["block_size"], r["spec"]["k"]) for r in rows}
    assert len(pairs) == 96
    assert {(b, k) for b in (8,16,32,64,128,256) for k in (1,b)} <= pairs
    fixtures = HERE / "artifacts/native_prepare"
    fixtures.mkdir()
    def source(ids):
        return dict(samples=[dict(logical_sample_id=f"sample-{i:04}",
                                  path=f"/declared-only/{i}.jpg", label=i % 1000) for i in ids])
    train, final = source(range(30)), source(range(100,110))
    (fixtures / "train.json").write_text(json.dumps(train))
    (fixtures / "final.json").write_text(json.dumps(final))
    task = dict(model=dict(family="resnet50", classes=1000, stem="declared", small_input_policy="declared"),
                rgb_preprocessing=dict(source_recipe="fixture", train="crop/flip", evaluation="center crop"),
                hardware=dict(gpu_uuid="fixture", gpu_name="fixture", cpu_threads=1,
                              host_memory_bytes=1024, cuda_memory_bytes=1024),
                training=dict(scratch_epochs=1, transfer_epochs=1, seed=7, optimizer="fixture", transfer_state="declared"),
                final_training=dict(epochs=1, confirmation_seeds=[7]),
                runtime_candidates=dict(batch_sizes=[64], data_workers=[0], decode_workers=[1], cache_bytes=[0]),
                split_seed=7, search_val_count=6, train_manifest="train.json", final_manifest="final.json",
                objective=dict(metric="min_e2e_latency_ms", accuracy_unit="percentage_points", accuracy_delta_pp=.5,
                               reference_candidate_id="B008_k008_s1x1_q050"),
                budgets=dict(search_gpu_hours=8, latency_limit_ms=None, storage_limit_bytes=None))
    task_path = fixtures / "task.json"
    task_path.write_text(json.dumps(task))
    result = search.prepare(task_path, fixtures / "prepared")
    splits = json.loads((fixtures / "prepared/splits.json").read_text())
    assert len(splits["train_fit"]) == 24 and len(splits["search_val"]) == 6 and len(splits["final_evaluation"]) == 10
    assert not set(splits["train_fit"]) & set(splits["search_val"])
    assert result["headline_eligible"] is False and result["status"] == "N1 only: no candidate trained/profiled/selected"
    for key in ("task_input", "train_source", "final_source", "candidates", "splits"):
        ref = result[key]
        assert ref["sha256"] == hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest()
    conflicts = []
    for alter in ("same_id", "same_path"):
        damaged = json.loads(json.dumps(final))
        if alter == "same_id":
            damaged["samples"][0]["logical_sample_id"] = train["samples"][0]["logical_sample_id"]
        else:
            damaged["samples"][0]["path"] = train["samples"][0]["path"]
        try:
            search.isolated_splits(train, damaged, search_val_count=6, seed=7)
        except ValueError as e:
            conflicts.append(dict(conflict=alter, error=str(e)))
        else:
            raise AssertionError("overlapping source accepted")
    return dict(candidates=len(rows), blocks={str(b): sum(r["spec"]["block_size"] == b for r in rows)
                                           for b in (8,16,32,64,128,256)},
                split_sizes={k: len(splits[k]) for k in ("train_fit", "search_val", "final_evaluation")},
                overlap_rejections=conflicts, scope=result["status"],
                content_binding=result["source_identity_scope"], headline_eligible=result["headline_eligible"])


results = dict(scope="Original Round-3 modules; NumPy-only; absent common.sha256_file helper provided; no Torch execution",
               implementation_hashes={name: hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()
                                      for name in ("store.py", "contracts.py", "native.py", "native_search.py")},
               round2_payload_regression=scope["payload_rewrite"](),
               round2_lifetime_regression=scope["lifetimes"](),
               round2_scatter_cache_regression=scope["scatter_and_cache"](),
               cache_only_fix=cache_only(), native_n1=prepare_native())
(HERE / "results.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(dict(status="passed", cache_only=results["cache_only_fix"], native_n1=results["native_n1"],
                     results=str(HERE/"results.json")), indent=2))
