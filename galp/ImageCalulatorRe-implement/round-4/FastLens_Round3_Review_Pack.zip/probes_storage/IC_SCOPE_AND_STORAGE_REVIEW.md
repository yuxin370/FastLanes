# Round 3: IC 固定 checkpoint 范围与存储审查

审查对象：`submission/current_repo/galp/benchmarks/dct_baselines`。实现只读。原始附件、产品源码和前两轮产物均未修改。以下行号相对此次 `current_repo`。

## 结论

对于「同一 checkpoint、同一预处理、同一输入张量」的 FastLens 实验，采用 IC-style NPZ 和 FS-style diagonal storage 作为存储适配 baseline 是合理范围。这里不需要完成 IC-native 的有损表示搜索。原生 IC self-design 应只在声称比较完整 IC 部署系统或 accuracy–latency/storage Pareto 时另设实验。

Round 3 的存储核心只改动了 Round 2 的全缓存请求内存准入及计数；独立 NumPy 回归全部通过，原来的全缓存请求误拒绝已修复。没有发现新的存储正确性阻断问题。原生搜索新增的 `native_search.prepare` 确实仅完成 N1 的任务、候选和数据切分冻结，未执行训练、profiling、selection 或 final deployment。

## 用户问题中的四种「全部数据」

| 层次 | 固定 matched 实验要求 | 当前行为 |
|---|---|---|
| 全部样本 | 使用同一数据集、相同样本/标签和 occurrence 顺序；不能靠删样本提高吞吐 | `training_store_identity` 检查人口集合、标签、路径、all64 mask；`store.py:30–46` |
| 每图完整信息 | 保留相同 JPEG 源的 q/Q；若裁剪/丢频不改变任何承诺的模型输入，可作为另行证明的物理优化 | `build_store` 原样保存 q/Q；只有显式 FixedK 可裁频；`store.py:72–81,106–158` |
| 每次逻辑读取 | 只需本次请求的空间区域与源频率依赖；不等于每次读取整张图，更不等于整数据集 | crop 转换为组件区域；`contracts.py:93–97`。当前 source512 profiles 固定 all64；`materialize.py:49–54` |
| 实际物理读取/解压 | 受存储格式粒度决定，可能比逻辑需要更多 | IC 一图或一组 NPZ；FS 所需 diagonal 的整 group member；`store.py:285–325` |

例如 source512 4:2:0 的三个分量共有 `(64²+32²+32²)*64=393216` 个 q。中心448 crop 逻辑上需要 `(56²+28²+28²)*64=301056` 个 q，占76.5625%。这是依据代码几何的计算，并非实测I/O。IC 的冷 NPZ 路径依然读取并解压整个 image/group member；FS 的 all64 请求触及全部15条 B8 diagonal。空间 subset 并不自动带来同等比例物理字节下降。

## 固定输入尺寸不等于读取所有源系数

必须冻结的是张量的值、通道含义、数值尺度、顺序与 shape，而不只是 shape。原生 IC 可以把不同的有损表示 reshape/补零成同一 shape，但这仍会改变 checkpoint 看到的数值。

当前变换先 crop、dequantize、spectral resize，然后 round/clamp，最后挑输出通道（`materialize.py:106–144`）。设 resize 为 `R`，输出通道选择为 `P_K`，则源系数需求取决于 `P_K R` 的非零依赖，而不能直接用 `K_out` 替代 `K_source`。当前实现选择 all64 作为安全完整依赖，并由 `contracts.py:100–111` 强制执行。现有证据不等于证明每个模型、每种 crop/resize 的64列都不可删；若以后要缩减，需要独立推导依赖并验证所有支持的变换。固定形状本身也不构成这种必要性证明。

一个简单反例：若没有频率混合 resize，模型只取某8个源频率，则固定输出shape仍可只读取那8个源频率。反之，固定24个输出通道经过混合 resize，可能依赖更多乃至全部64个源频率。

## IC 原生搜索搜索什么

原论文 §3、§4.1–4.3：同一个 dataset/model/hardware 下搜索采样、块大小 B、保留三角 k、标量量化 q。搜索不是选择哪些 dataset 样本计入工作量，而是改变每张图如何表示及保留多少信息，并训练/迁移相应模型。Build 建性能模型；Exploration 按时间/容量预算给出格式和准确率；Deploy 最终训练后使用选定格式。

论文 §4.2–4.3 的设计域是4种采样、B∈{8,16,32,64,128,256}、k=1..B、q∈{20,50,100}，共6048个配置。论文 §5.1 主实验固定 no-sampling/q50，从 B/k 中使用96个候选；具体96名单没有公开。本次实现明确采用项目自己的固定子集，合理披露了这个差异。

重要边界：B8、k8 的原生 IC 三角只保留36/64个信息系数。当前 JPEG all64+原始 Q 的 matched adapter 不是原生 IC 表示搜索域中的一个普通候选，也不是其原生三平面 mosaic 的等价重命名。应称为「paper-guided IC-style image-major NPZ, JPEG-DCT matched」，避免称作完整原版 IC。

当前固定 exact-input 合约下，原生有损参数基本不能自由改动。仍可调的是无损与物理执行参数：合法整数位宽、image/batch/group布局、chunk/文件粒度、解压线程、prefetch/cache及有界并行。它们是存储/执行调优，不等于原论文 self-design。改变 codec 或明显偏离论文的工程增强应独立标注。

## 剩余 IC 机制为什么仍值得作 baseline

- 原始整数 DCT 系数的直接存储与恢复，省去运行时从 JPEG 字节重新抽取系数；实际是否更快需测量。
- NPZ/DEFLATE 对数值冗余的无损压缩。
- 一图一个存储对象及 IC-b 批量对象两种访问局部性。
- model-ready DCT 路线的输入管线对比；同一 checkpoint 下不能引用 IC 原生缩小 mosaic 带来的模型计算下降作为已实现优势。

全部频率时 FS 的列裁剪优势不出现，但列组织压缩、不同整数位宽、批量读取和缓存/共享仍可比较。其多消费者优势在相同单一 workload、all64 条件下被自然固定，论文结论应限定于该 workload。

## 复用架构建议与当前实际状态

建议固定一个系数接口：`(sample_id, component geometry, crop regions, requested source frequencies, original q, Q)`。公共部分冻结样本/augmentation trace、crop/resize/round/clamp语义、通道选择与 normalization、Mixup、batch/accumulation、模型/checkpoint/optimizer。存储 backend 负责索引、物理读取、解压、scatter/缓存；返回等价 q/Q 即可。

当前已有这条方向：

- CNN `StoreDctDataset` 继承 `JpegDctDataset`，替换 q/Q acquisition 后调用同一 `transform`，`training_jpeg.py:87–124`；共用几何 `59–84`，GPU RandAugment/Mixup `145–149,182`。
- Transformer 存储 q/Q 进入同一个 `_transform`，`system_rgbnomore/training/pipeline.py:513–551`。

但不能称「后面完全相同的实现」：这些 baseline 当前仍在 CPU worker 做几何，FastLens 使用优化 GPU 路径。若要归因纯存储差异，可增加共用 materializer 的对照；若要测各自优化的端到端管线，可保留 FastLens 融合执行，但 IC/FS 应同样允许使用可复用的 GPU 后处理，并在相同总 CPU/GPU/内存预算下调优。必须检查最终tensor，而不能因为复用了部分代码就自动认为一致。无须为了统一接口强迫 FastLens 物化多余的中间数组或先解完整数据。

## 独立复核

执行：`probe_round3.py`，Python/NumPy，仅以普通 SHA-256 helper 补齐当前源码包缺少的 `galp.benchmarks.common.sha256_file`。没有 Torch/CPU参考/GPU计算的模拟。

- 重新使用上一轮存储回归定义，只替换源码路径：q/Q 合法重写后8次 preflight/read 拒绝；1与4worker的有界真实解压数组生命周期；ragged/crop/部分频率/重复与乱序请求；缓存热读。
- 新全缓存准入：member1664B + output1664B，memory3328B恰好通过。0 read、0 decode、0 active-decoded；resident/cache/output counters正确。重复输出超过预算、同预算冷miss均拒绝。
- 原始 N1 `prepare` 实际执行：96唯一、可复现候选，所有 B 的 k 端点存在；fixture切分24/6/10，ID/path重叠拒绝；5个产物/源引用哈希一致；`headline_eligible=false`，状态为 `N1 only: no candidate trained/profiled/selected`。
- 候选 B 分布为3/3/9/11/20/50；这是从剩余 `(B,k)` 对均匀抽样，而不是按 B 分层平衡。与 README 描述一致，本次不作为阻断问题。

结果：`results.json`。源码修改点是 `store.py:365–378,437–439`。N1边界见 `native_search.py:102–147`、README415–483。其后阶段未实现的事实不应成为本次固定 checkpoint matched-storage 主线的阻断要求。

复核脚本需要新建输出目录；它按实现的 fail-on-existing 规则拒绝覆盖 fixtures。未执行完整父仓库、Torch/CUDA数值gate或性能实验。生产gate、正式训练identity与计量状态由并行审查汇总。
