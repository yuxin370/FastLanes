# FastLens 第三版审查与固定 checkpoint 存储基线方案

审查日期：2026-10-10。对象：本次提供的 dct-round3-review.zip，以及同一会话提供的 Image Calculator 和 Frequency-Store 论文。产品代码只读。

## 一 结论与本轮范围调整

**对于已有 checkpoint、固定预处理和相同模型输入的实验，正确主线是 IC/FS 存储适配，再复用现有模型侧处理。完整 Image Calculator 原生表示搜索不再是这条主线的验收条件。** 上轮 N1–N4 是比较完整自设计系统时的扩展要求；依据这次明确的实验范围，应移出主线必做项。

第三版已经形成合理的存储适配结构，修复了上一轮全缓存请求的内存准入问题，并提供了明显更强的 H100 数值验证。当前状态适合表述为：**存储核心与接入结构基本合理，指定 ViT 训练数值 fixture 有通过记录；固定预训练 checkpoint 的完整 matched 推理实验仍待验收。**

本轮新增两个需要处理的 native 问题：一个既有的分批 projected output 完成映射错误，以及最近 down2 修复新增的 GPU scratch 未计入公开 transient 总量。前者的原始 C++ 调度函数已产生确定性 CPU 反例，但当前 ViT gate 与正式 PLS 训练未启用该分支，不能据此否定它们的已有通过记录。

实验中的方法名称宜采用 IC-style matched DCT、IC-b-style matched DCT、FS-style matched DCT B8，并在方法说明中写明保留和适配了哪些机制。当前实现不应称作原生 IC 的完整自设计部署结果。

## 二 IC 搜索的究竟是什么

### 1 全部样本与每张图的全部信息是不同要求

原生 IC 的搜索保持同一个图像任务，改变每张图如何表示。论文讨论的主要维度是行列采样、DCT 块大小 B、左上三角保留参数 k、标量量化因子。不同表示会改变输入的信息量、形状、解压成本和模型计算，搜索借助表示对应的模型训练或迁移、性能建模与实测进行选择。它并不是通过挑选更容易的图像、少处理一部分 evaluation samples 来获得吞吐。原论文依据见 §3、§4.1–4.3、§5.1；作者的后续教程也区分了 Sampling、Partitioning、Pruning、Quantization 四个设计维度。[P1][P2]

所以，“不能选择哪些数据被使用，只能调整参数”需要分开理解：

| 约束 | IC 还可以改变什么 |
|---|---|
| 只要求所有图像样本都参加 | 仍能改变每图的采样、块划分、频率保留和量化；所有样本依然参加 |
| 固定 checkpoint 和 shape，但允许输入近似、accuracy 变化 | 某些形状兼容的有损候选仍可用该 checkpoint 验证，但这是 accuracy 约束下的表示近似实验 |
| 固定原始 JPEG q/Q、完整预处理语义和最终输入 | 原生有损表示空间基本被冻结；只剩保持契约的无损编码、物理布局和执行调优 |

参数并不是与数据选择无关的中性开关：原生 k、采样和量化恰好在决定每张图保留哪些信息。另一方面，仅仅固定 checkpoint 并不在逻辑上禁止所有有损输入；排除这些变化的是本实验额外承诺的相同输入语义。

### 2 当前 matched 任务没有原生 IC 的最优表示问题

设源图像 JPEG 系数为 q_i，量化表为 Q_i，固定预处理为 F，固定请求及裁剪决定为 a_i。目标为：

    x_i = F(q_i, Q_i, a_i)
    x_i(IC) = x_i(FS) = x_i(FastLens)

同时固定 checkpoint、样本和标签、顺序、共同模型执行契约（如精度、batch）及全局资源预算；各 backend 的物理执行参数分别调优并冻结记录。这里的无损指保留已经给定的 JPEG q/Q，不是从有损 JPEG 恢复最初未压缩的 RGB。

在这个约束下，没有必要为了“生成最佳表示”训练几十个 IC 候选模型。可以做一个小规模、公开预算的工程调优：合法整数位宽、image/batch/group 粒度、线程数、缓存、预取和有界并行。所有候选必须先通过同一输入等价检查，再在独立调优 trace 上比较成本，冻结配置后用于报告。时间和内存预算按整个进程树与所有 worker 合计，不能给每个 worker 各自一份全局预算。

如果改变 codec、排列方式或增加共享 GPU 后处理，应说明是对论文机制的工程适配；没有原始代码时尤其不应声称官方字节格式兼容。

### 3 all64 也不是原生 IC 的最大三角参数

原论文的 B×B 左上三角 k 范围到 B；在 B=8、k=8 时，满足 u+v<8 的系数只有 36 个。当前 matched adapter 保留原始 JPEG 的全部 64 个系数与原始 Q，其序列化按 image/component/raster-block/stored-mask 展开，也不同于原生 IC 三平面 mosaic 的行顺序。

因此，当前 all64 版本不是在原生 IC 候选域内简单选一个“最大 k”。它是将 IC 的整数 DCT、image-major NPZ 与批量对象机制用于 JPEG-DCT matched 实验。36/64 是三角定义的计算，源码也把不属于原生三角的 mask 标为 matched_arbitrary_adapter。[P1][S1]

## 三 固定尺寸是否要求读取全部数据

### 1 四个层次应分别记录

| 层次 | 实验要求或含义 |
|---|---|
| 样本集合 | 同一完整数据集，同样的样本 occurrence、标签与顺序 |
| 存储内容 | 当前共享存储主线保留所有源 JPEG q/Q，支持承诺的裁剪与模型 profile |
| 每次逻辑请求 | 只需生成这次模型输入所依赖的空间区域和源频率 |
| 每次物理读取 | 由文件、压缩 member、group 和缓存粒度决定，可能多于逻辑请求 |

存储全数据不等于一次载入全数据；固定输出尺寸也不等于一次读整张源图。

### 2 当前 all64 来自预处理依赖

当前处理先 crop/dequantize，再做 spectral resize、round/clamp，最后取模型输出通道。设 resize 为 R，选通道为 P_K，则源依赖取决于 P_K R，不能直接把输出的 K 个频率当作源端只需的 K 个频率。

当前 materialize.py 明确将三分量源频率设为 all64；contracts.py 对当前 source512 resize profiles 强制这个契约。它是安全的完整依赖策略。现有证据没有证明每个 profile、每种 crop 的 64 列都数学上不可减少；将来若做依赖裁剪，需要对所支持的变换证明和验证。没有频率混合、且模型直接只读指定 8 个源频率的情况，就是固定 shape 仍可只读部分源频率的简单反例。[S2][S3]

### 3 all64 仍然可以只覆盖 crop

以当前 512×512、4:2:0 源图及对齐的 448×448 crop 为例：

- 整图系数个数：(64² + 32² + 32²) × 64 = 393216。
- crop 系数个数：(56² + 28² + 28²) × 64 = 301056。
- crop 逻辑请求占整图 76.5625%。

这是依据分量 block geometry 的计算，**不是实测读取字节比例**。当前 IC 冷读会读取整个 image/group NPZ，然后解压相应 member，再 scatter 到请求区域；IC-b 还可能同时包含未请求图像。当前 FS 的 B8 all64 请求触及所在 group 的全部 15 条系数对角线，不能利用频率列裁剪节约读取；组内空间与样本过读仍然存在。[S1][S3]

固定尺寸只固定输出的形状。通道含义、数值尺度、resize 顺序、量化表、round/clamp 和归一化有任何差别，即使 shape 相同也不能自动视为相同 checkpoint 的 matched 输入。

## 四 IC 在这个范围内还贡献什么

即使不执行原生有损表示搜索，仍有值得测量的存储机制：

1. 提前存储整数 DCT，省去每次从 JPEG 字节重新解析并抽取系数的步骤；实际净收益取决于存储体积与读取成本。
2. NPZ/DEFLATE 对数值数组的无损压缩。
3. 一图一个对象的独立访问，及 IC-b 一组图像一个对象的批量读取和压缩局部性。
4. 解压线程、缓存、预取及整数位宽的执行取舍。

原生 IC 缩小 mosaic 后减少模型计算的收益不属于这条相同 checkpoint、相同输入的 baseline。FS 的按频率列组织、不同列的数值分布与整数表示、批量读取和多请求共享仍可研究；在单一 all64 workload 下，频率裁剪优势自然不出现。实验应限定这一条件，而不是由此推断 FS 的全部能力。[P1][S1]

## 五 推荐架构与当前接入状态

### 1 公共接口应放在系数和输入语义边界

建议复用已有结构，给存储 reader 一个小的公共契约：

    sample/occurrence identity
    component geometry and sampling
    crop block regions and requested source frequencies
    original integer q and Q
    physical-read/decode/cache counters and ownership

| 部分 | 各 backend 保留自己的实现 | 应共用或冻结的部分 |
|---|---|---|
| 存储 | 索引、文件/group、压缩、实际 I/O、decode、cache、scatter | 同一源与请求契约，真实字节及资源口径 |
| 系数交接 | 真实 packing、dtype 转换、CPU/GPU 交接 | q/Q 数值、分量几何、请求输出顺序 |
| 模型预处理 | 优化路径可保留融合；纯存储对照使用共同 materializer | crop、resize、round/clamp、通道选择、normalization |
| 模型推理 | 同一推理调用 | checkpoint 权重、model.eval、精度、batch、输出统计 |
| 训练扩展 | 沿用现有训练循环 | augmentation trace、Mixup、初态、optimizer、scheduler、accumulation |

IC/FS 负责接入真实存储，模型侧复用现有部分，这个方向正确。没有必要各自再写一套模型、训练器和 augmentation 框架。

### 2 第三版已经部分实现

CNN 的 StoreDctDataset 继承 JpegDctDataset，按真实微批合并读取 q/Q，再调用同一个 transform；GPU augmentation 与训练循环也沿用既有路径。Transformer 的 baseline_store 分支同样把恢复的系数送入既有 _transform，后续 RandAugment/Mixup 等复用原流程。[S4][S5][S13]

但不能把“语义与部分代码复用”写成“所有后处理执行完全相同”：当前 IC/FS 在 CPU worker/materializer 做几何，FastLens 走 native CUDA 路径。UnifiedReplay 的两个分支也清楚体现了这一差别。[S6]

因此建议报告两种有明确目的的实验：

- **共同后处理的存储适配对照**：尽量在同一 device、相同 q/Q 或规范化 dense DCT 边界交接，调用同一组已有后处理算子。每条路径为到达共同交接边界所发生的 packing、dtype/layout 转换、同步和 H2D 均计时。该对照更适合解释存储与读取的贡献。
- **实际部署的完整输入管线对照**：保留 FastLens 的融合执行，让 IC/FS 使用合理且预算相同的优化配置；最终输入与 checkpoint 不变。该结果解释整个输入系统的端到端差异。

不要为了公共接口让 FastLens 的正式路径额外做不必要的 CPU roundtrip，也不要将 CPU 几何与 GPU 融合几何的全部差距归因于磁盘格式。若现有 GPU 算子没有独立入口，只增加最小适配入口，不重建平行框架。

## 六 第三版实现状态

| 项目 | 本轮结论 | 证据边界 |
|---|---|---|
| 存储 q/Q 内容绑定、crop、部分频率、重复/乱序、scatter | 独立 NumPy 回归通过 | 执行原始存储模块；未用替代 reader |
| 全缓存请求预算误拒绝 | 已修复 | 恰好容纳 cache+output 的边界例通过；超预算与冷 miss 正确拒绝 |
| 真实微批读取接入 | 已实现 | CNN/Transformer 复用既有 transform 和模型流程 |
| M1 专用 matched launcher | 已实现 | 新 launcher 全部 B6；检查声明身份与实际消费顺序 |
| M2 batch64、accum16、tail | 有更强通过记录 | 真实8194图 fixture；calibration/verification 各4097图，互不重叠 |
| 最近跨 workset down2 数值修复 | 机制合理 | C++ planner 与 CPU FP32 代数支持；提交 H100 记录通过 |
| 固定预训练 checkpoint 推理 | 本包尚未完成验收 | 当前生产大小数值 fixture 明确 from_scratch |
| 多 pool、多 worker 的正式完整推理性能 | 尚待对应证据 | UnifiedReplay 逐微批运行并预存输入，不是完整持续吞吐路径 |
| IC-native search | 只完成 N1 prepare | 未训练/profile/select；在本轮范围中属于可选扩展 |
| 论文主结果资格 | 暂不应宣布全部就绪 | 仍有下述 native、输入身份、版本与推理验证缺口 |

M1 的新 matched_training.py 将 JPEG/native/IC/IC-b/FS 都置于 B6 条件和4096图 pool，并比较模型初态、recipe、runtime、微批/accumulation、样本顺序与实际 pool/update 等。旧 cnn_training_baselines.sh 保留历史 A0/B6 安排是兼容性选择；不能再次把“旧脚本没改”作为否定新严格入口的理由。独立 probe 执行 check_pair，匹配 fixture 通过，condition、初始模型、runtime、消费顺序改变均被拒绝；没有运行完整训练身份生成，因为导出缺少其部分父仓库依赖。[S7][V3]

缓存状态的说明也已改为 unmeasured/post-verification，第二轮不再自动标作 guaranteed warm。正式性能与全局资源 gate 仍未完成；保留 headline_eligible=false 是准确的状态说明。

## 七 需要处理的具体问题

### R3 01 P1 分批输出完成使用了错误的图像索引

**性质：当前源码中的确定性调度映射问题；在 base_HEAD 已存在，不是本次 down2 补丁引入。CPU 反例已执行，特定 GPU 路径的实际症状尚需回归。**

当前请求会按 shard/local-image 的物理顺序排序，descriptor 仍保存原始 output_slot 为 image.request_index。CUDA 实际写 tensor 采用 request_index，但 build_output_batch_completion_schedule 在 jpeg_dct_planner.cpp 第784行用 descriptor image / batch_images 分组完成点，调用方没有传入输出索引映射。[S8][S9][S10]

最小反例：原始请求是反序；物理 descriptors 的 request_index 为 [1,0]。descriptor0 只在 workset0 完成，descriptor1 只在 workset1 完成，output_batch_images=1。原函数报告 output0 在 workset0 ready，但它真正的最后 writer 在 workset1。问题也可能导致对不完整 projected accumulator 提前 finalize/normalize，再加入后续未归一化贡献；等到整批结束不一定能补救。[V2]

影响范围必须限定：

- 分支位于 block-major planless 路径，要求非零 output_batch_images、projected output、FP32。
- 正式 PLS 训练虽然 pool4096/microbatch64，但 device.output_batch_images 默认0，且后处理等待完整 source event，所以本问题分支未启用。
- 本次成功记录是 ViT-Ti 非 projected profile；UnifiedReplay 又逐个最多64图微批提交，不覆盖多个输出微批之间的这个映射。
- CNN 公共 API 可以接受大于模型微批的 preparation batch，并启用分批 projected output；乱序/重复请求和不同最后 workset 是需要覆盖的组合。
- evaluate_shards.py 的性能路径启用分批 projection，但现有 activation_groups 通常提供物理递增 ID，可能掩盖问题；其 --verify 反而关闭 streamed_projection，故该验证分支不能证明性能分支的分批完成正确。
- 一部分 logical wrapper 可能让 consumer 等整批；相关完整包装实现不在本包。不能据 CPU 反例宣称附件 H100 日志已经发生错误，但也不能用整批等待自动排除提前 finalize 对数值的影响。[S11][V3]

**最小修复**：completion planner 接收 descriptor 到 request_index 的映射，按真实输出 slot 计算最后 writer；保持物理调度与 split-source slots。补原始 C++ 反序跨 workset 回归，以及同一 streamed projected 路径上的乱序、重复、多输出批、第二 consumer stream CUDA 回归。

### R3 02 P2 新增 source scratch 未计入公开 transient 总量

最近修复对每个需要保留源值的跨 workset down2 输出保留256个 float，即 1024×N_split 字节。GPU 上实际分配了 source array 与 metadata，但新增 schedule 计量主要覆盖 host metadata，ActualTransientMemoryTracker 的公开总量没有包含这块 source scratch。512 MiB gate 与 peak_transient_bytes 继续使用不完整总量。[S9][S12]

native allocator 总量能够看到这次分配，不能说所有 GPU 指标都漏了。问题是公开 transient 工作集与其预算检查缺项。slots 在一次执行内不复用，所需容量随所有 split outputs 增长；reader 还会保留 reserve capacity，因此必须同时记录 used bytes、capacity 和真实生命周期。

**最小修复**：把新增 source 与 device metadata 的实际占用接入既有 tracker；明确512 MiB约束的是完整 transient 还是 decode arena。如果是前者，准入也必须包含新增缓冲。先测目标 pool 的 N_split 和峰值，不需要立即设计复杂 slot cache。

### R3 03 P2 正式 matched 身份检查还不能单独证明当前源图内容一致

training_store_identity 检查样本集合、标签、路径、all64 mask 和存储身份，但没有重新确认这些路径下当前 JPEG 的内容哈希。独立 probe 创建一个合法 store 后替换同一路径的 JPEG，函数仍返回相同身份；store.verify_content 也正确地继续接受未改变的 NPZ。这说明两项检查分别证明了不同的事情。[S1][V3]

这不推翻已有 G1，因为 G1 对实际源系数进行了比较。问题是正式结果的身份配对不能代替源内容验证。

**最小修复**：在正式推理/训练启动或已有 preflight 中绑定同一次 common-source/G1 结果与当前源 manifest；必要时对照已有 JPEG hash。复用现有内容绑定，不另建证据系统；验证成本与 cache 状态要单列。

### R3 04 当前通过的是 from-scratch 训练数值状态

本轮 profile 明确写明 checkpoint 仅为 inference reference，训练从另行哈希的完整 snapshot 开始；config 的 initialization 是 from_scratch。CNN 的 build_training_model 读取模型后会 reset_parameters，Transformer factory 构造新模型。因此 checkpoint 路径/哈希出现在 profile 中，不代表这次 gate 使用了预训练权重。[S6][E1][E2]

该设计对验证 loss、grad、parameter、optimizer 的同初态演化是合理的。但用户目前要比较的是已有 checkpoint 下的输入和推理表现，所以下一步应加载实际预训练权重并核对实际 state_dict 身份，保持原验证预处理，检查最终 tensor、logits、预测以及任务指标。

无需为此完成 IC-native 搜索或重新训练所有模型。最近 CUDA 修复没有改变存储格式或 checkpoint 文件格式。只应对实际经过受影响路径的当前推理配置重验输入及性能；旧训练曲线仍是其原版本的结果，不能自动重标为新实现的结果。

### R3 05 通过记录没有覆盖一个完全相同的当前版本

本地核对了10份 calibration/verified JSON 的150项 baseline Python module 引用，其中142项与当前文件一致。8项差异实际都指向同一个 unified.py：前四个 backend 的各两份记录使用旧 SHA，FS retry 使用当前 SHA。旧 unified.py 的精确快照未提供。

旧记录可以保留各自版本下的证据价值，但不能合并写成“当前同一版本五个 backend 全部验收”。应冻结接下来用于实验的源码/配置，恢复旧快照以解释差异，或针对实际变化重验受影响路径。后续正式推理本来就需要最终版本的结果，无需机械重跑所有历史实验。[V4]

FastLens 记录确实含 binding .so 和 coefficient bridge SHA。二进制本身未附，因此本地无法核对实际 binary bytes 或构建到当前 native 源文件的对应关系。缺的是本地验证条件，不是记录完全没有二进制身份。[E1]

### R3 06 P3 非默认 clamp 的 padding 边缘条件

公开 API 允许不包含0的合法 clamp，例如 [10,32767]。普通路径对 padding 使用 clamp(0)，新 split-source 路径对越界位置留下 memset 的 literal0。若同时发生 padding 与跨 workset down2，二者可不同。CPU 代数探针得到47个最终取整差异。[V2]

当前 matched 默认 clamp 包含0，完全不受此项影响。若要保留整个已有 API 契约，可在最终源矩阵中区分真正越界位置与当前 workset 缺席位置，对前者使用 clamp(0)。此项低于主线映射、计量和真实推理验证。

## 八 最近 down2 修复为什么合理

旧路径先分别对各 workset 的部分源系数做 FP32 变换，再相加。实数线性运算可以如此分解，但浮点求和和乘加顺序可能改变半整数附近的最后取整。新路径保存 dequantize/clamp 后的完整源值，到最后 owner 时只执行一次原有两遍变换，针对性消除了这种计算分解变化。[S8][S9][S10][P3]

本地编译的是从当前源码提取的 build_split_down2_plan 和 completion 函数，配以精简数据结构和独立 ownership oracle；没有编译完整产品或执行 CUDA。结果：

- 1200个随机 direct/repeated/grouped schedule 的 split slot 唯一性、最后 owner 与数量检查通过。
- descriptor 顺序就是输出顺序时，多种 output batch size 的完成点检查通过。
- 1503个 CPU FP32/std::fma 例子中，先 gather 再按原顺序计算都与完整源计算逐位相同。
- 旧 partial-transform-then-add 在这些生成例中产生1223个最终取整不同的系数；一个例子为完整源30.500003814697266，而 partial sum为30.5。

这是对根因机制的独立支持，不是用缺失的原始失败图进行 GPU 复现。代码中的 transform stream、decode/gather handoff 和 scratch fence 结构合理，标准契约下没有找到新的确定性源值丢失或竞态；仍应补少量真正跨3–4个 workset、带 flip、重复请求、第二 consumer stream 和 reader 复用的 CUDA 回归。[V2]

## 九 提交 H100 证据能支持多强的结论

### 1 数据与实际更新结构

calibration 和 verification 各有4097个不同样本，交集为0，共8194图。每个阶段有64个 batch64，再加1个单图尾批；optimizer update 实际样本数为 [1024,1024,1024,1024,1]，对应微批数 [16,16,16,16,1]。这比上一轮微小合成样本、名义 accumulation 的证据明显更强，真实覆盖了 accumulation16 和不完整尾部更新。[V3][V4]

本包成功记录的五种配置是 CPU-DCT、FastLens、IC 单图、IC-b 批量和 FS，各有 calibration 与 verification。记录中的输入、logits、loss、gradient、parameter、optimizer 误差字段均为0，q/Q 与 target 精确比较也通过。它们共享 config/profile/source 与训练初态。配置的 total_updates=375600 是 scheduler 的设置，不是本次执行了375600次更新；实际每阶段5次。[E1][V4]

这是提交者 H100 FP32 运行记录，本地只完成其代码语义和 artifact 引用核对。本环境没有 Torch/CUDA、原始8194图、真实8755个 NPZ payload、训练 snapshot 和所录 native 二进制，未重新运行 GPU gate。原始附件本身也不构成一个可本地完整重建的 parent repository。

### 2 源生产过程与 retry

producer 记录对选中的8194图给出了当前512源生成方式的逐图字节等价核对：RGB、BILINEAR stretch512、JPEG 默认参数与明确 quality75/subsampling2 的一致性。历史 validation 生产命令没有恢复；当前记录准确地把结论限定为选定 fixture 的 byte-equivalent reconstruction。本地核对的是这些声明、manifest 与 trace 引用的一致性，不是未附图像的实际字节。[E2][V4]

第一次 FS 校准的 GPU OOM 日志显示另一个进程占用约74.17 GiB，当前进程约4.75 GiB，随后 retry 通过。该次失败与共享 GPU 资源竞争一致，不能据此说 FS 本身不能运行。正式性能实验仍应固定并记录实际 GPU/CPU 资源状态。[E3]

### 3 尚未覆盖的正式运行层

UnifiedReplay 每次启动一个模型微批，并把实际/reference 输入先收集后做 paired training，因此不测正式持续多 pool、多 worker、slot 复用和异步消费的吞吐。提交的是数值 fixture，且标注 numerical_fixture_only=true。无论用了真实图还是 production-size batch，都不能将它的墙钟直接充当输入系统性能。[S6][E2][V3]

现有正式统计对已消费 pool 计数，可能不包含未消费 lookahead；CPU RSS 在 pool 边界采样，简单求和会重复计共享页，RUSAGE_CHILDREN 的最大退出进程也不等于整个 pipeline 的峰值。后续实验应补与真实生命周期一致的统计口径，而不是为了通过 gate 人为增加虚构吞吐或资源字段。[V3]

## 十 交给 agent 的最小开发顺序

### 任务 A 冻结正确实验范围

目标：把默认实验明确为已有 checkpoint、同一 JPEG q/Q、同一完整输入语义的 storage-adapted baseline。保留 IC-native prepare 为可选研究入口，不让 N2–N4 阻塞主实验。

验收：每个结果声明 checkpoint 实际权重身份、profile、源内容身份、trace、backend 存储配置、源码/二进制身份及实验类型。说明哪些步骤共用，哪些是融合实现。已有历史脚本和数据格式继续保留；不要把旧 A0/B6 结果自动升级为 matched。

### 任务 B 修复窄范围 native 正确性与计量

修改 completion planner 的 descriptor→request_index 分组；给 split-source used/capacity/device metadata 接入既有 transient tracker。先使用本包确定性反例，随后新增或扩展同一 streamed-projection 路径的定向 GPU 验证；验证该分支时不能通过关闭分批模式获得通过，既有 --verify 的其他用途可以保留。

验收：反序、重复、多 workset、多输出批的实际输出和 ready/finalize 时序正确；所有未完成 writer 都在 finalize/event 之前。GPU 回归覆盖第二 consumer stream、立即复用 reader；资源总量包含新增缓冲，预算与公开字段一致。对当前零包含 clamp 先验收主线，P3 API 边缘项可随后处理。

### 任务 C 完成预训练 checkpoint 的推理等价验证

复用既有模型和推理入口，真正加载声明的预训练权重；记录实际加载后 state_dict 身份，禁止静默 reset 或 fallback。使用原有 validation crop/resize/normalization 与相同样本请求，覆盖预定模型 profile，至少包含 projected CNN 与非 projected Transformer 两条执行分支；主表涉及的 profile 都需要对应证据。

验收：相同 q/Q、标签、顺序、最终模型 tensor、logits/预测与任务指标；容差按既有数值语义预先声明，不能看到误差后放宽。先在正式微批/大 preparation batch 和 tail 上做定向 gate，再跑论文实际 inference 数据集。训练 G3 保留为训练实验需要时的补充，不再替代本任务。

### 任务 D 做共同后处理的存储对照并绑定当前源

复用现有公共后处理算子，给各 reader 建立最小系数交接；统一语义和 device 边界，每条路径为到达交接边界发生的 packing、dtype/layout 转换、同步和 H2D 均计入成本。FastLens 正式融合路径另行保留。正式启动关联现有 G1/common-source 内容绑定；更换同一路径 JPEG 的反例必须被拒绝或触发重验。

验收：common materializer 的算子与输入契约相同；明确交接前后的计时范围。存储体积计入索引/表等必需数据；同时输出请求 q 数、实际解压 q 数、应用读取字节与可观测物理 I/O。没有实测页缓存状态时使用明确的未测标签。

### 任务 E 冻结版本并测实际部署性能

基于最终源码和二进制运行正式推理 pipeline。对线程、group、cache/prefetch 做小预算调优，冻结后再报告；按相同全局 CPU 核心、GPU、内存、缓存状态和样本集合比较。共同后处理对照与各系统实际优化 E2E 分开报告。

验收：真实稳态吞吐、延迟分布、输入准备与 H2D/模型阶段、存储体积、CPU 时间、全局内存与 GPU transient/capacity；预取即使未消费也纳入成本或单列。记录 cache 状态与预校验成本。受 down2 变更影响的配置重测数值与性能；未经过该分支的历史实验不因文件改动而自动要求全部重训。

## 十一 本次复核材料与复现边界

原始 ZIP：11874950 bytes。

SHA256：e1a008b267261ebf562225c43baec7c028f890793bceb2bd98b2a9f6052e6cc6。

声明 base revision：13fabad2b337945ea32d50dd6b6cbebc5563b031，另含 dirty worktree 与未跟踪 baseline 文件。审查基于压缩包的 current_repo 及 base_HEAD，不把所有差异视为同一个提交。

复核包包含本报告、独立 NumPy/C++/artifact 探针、运行结果、各分支审查笔记和源码哈希索引。其脚本读取原始附件中的 submission，不包含原始8194张图片、NPZ、GPU二进制或完整父仓库。重新执行请按包内 README 在新的解压目录放入原始 ZIP 内容；存储负例会创建并修改自己的测试 fixture，不能在已经运行过的 fixture 目录上重复构建。

本次实际执行结果的主要定位：

- [存储回归结果](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/probes_storage/results.json) [V1]
- [C++ 调度与 CPU FP32 结果](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/probes_cuda/results.json) [V2]
- [集成 helper 与源身份反例](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/probes_integration/results.json) [V3]
- [记录、源码、manifest、trace 引用审计](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/probes_integrity/results.json) [V4]

## 十二 证据索引

### 论文与官方说明

[P1] Utku Sirin, Stratos Idreos. The Image Calculator: 10x Faster Image-AI Inference by Replacing JPEG with Self-designing Storage Format. Proc. ACM Management of Data, 2024, Article52. 本会话提供的论文全文，重点 §3、§4、§5.1。[DOI](https://doi.org/10.1145/3639307)。

[P2] 作者 SIGMOD2025 教程 Data Storage and Management for Image AI，§2.2 self-designed formats。[教程](https://www.utkusirin.com/sigmod25-image-ai-tutorial)。教程与2024论文的候选总数口径不同，本报告没有将两者的总数混用。

[P3] NVIDIA Floating Point and IEEE754，运算顺序与有限精度说明。[官方文档](https://docs.nvidia.com/cuda/floating-point/index.html)。本报告的具体修复与反例以本地源码和 probe 为依据，不以通用浮点文档证明具体 GPU 执行结果。

### 当前源码

[S1] [store.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_baselines/store.py)：training_store_identity，第30–46行；mask_family，第53–58行；序列化，第125–158行；物理 member 读取，第285–325行；cache 准入，第365–378及437–439行。

[S2] [materialize.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_baselines/materialize.py)：源频率契约，第49–54行；几何到通道选择，第106–144行。

[S3] [contracts.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_baselines/contracts.py)：crop 区域与 all64，第93–111行。

[S4] [training_jpeg.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_models/training_jpeg.py)：共享 transform，第59–84行；StoreDctDataset，第87–124行。

[S5] [Transformer pipeline.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/system_rgbnomore/training/pipeline.py)：baseline_store，第459–470、513–551行；共享变换，第553–594行。

[S6] [unified.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_baselines/unified.py)：CPU/native 分支，第188–219行；build_training_model，第240–250行。

[S7] [matched_training.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_models/matched_training.py)：check_pair，第38–64行；专用 launcher，第69–94行。

[S8] [jpeg_dct_planner.cpp](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/src/jpeg/jpeg_dct_planner.cpp)：split plan，第715–769行；完成调度，第773–825行；原始 request_index，第2766行。

[S9] [jpeg_dct_device.cu](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/src/jpeg/jpeg_dct_device.cu)：finalize，第2081–2106行；split buffer，第2340–2365行；tracker，第3161–3183行；gate，第5983–5984行；分批事件启用，第6727–6737行。

[S10] [jpeg_dct_transform_kernels.cu](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/src/jpeg/jpeg_dct_transform_kernels.cu)：request_index 写入，第384、401、409行；split gather/transform，第939–1122行。

[S11] [evaluate_shards.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_models/evaluate_shards.py)：activation_groups，第72–80行；streamed projection，第199–204行；按 range 推理，第279–295行。正式 PLS 和公共 API 的补充调用链见复核包 INTEGRATION_REVIEW.md。

[S12] [direct_dct_torch.cpp](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/torch/direct_dct_torch.cpp)：projected_range，第1819–1836行；公开 transient metric，第1993、2525行。

[S13] [training_pls train.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/training_pls/train.py)：共同 RandAugment/Mixup，第2119–2133行。

### 提交执行记录

[E1] [fastlens.verified.json](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/evidence/h100_first_four/fastlens.verified.json)：提交的 FastLens H100 记录、binary identity 与数值误差。

[E2] [production_gate.py](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/current_repo/galp/benchmarks/dct_baselines/production_gate.py)：fixture、producer 与执行参数。完整 profile/config/source 引用的核对见 V4。

[E3] [fs_calibrate.log](sandbox:/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission/evidence/h100_first_four/fs_calibrate.log)：第一次 FS GPU OOM 的实际进程内存状态；retry 通过记录在同一附件的 evidence/h100_fs_retry。
