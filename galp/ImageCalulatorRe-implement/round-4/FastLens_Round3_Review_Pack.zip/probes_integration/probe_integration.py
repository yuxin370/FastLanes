"""Read-only probes of the submitted code; no Torch/GPU execution.

The exported package omits galp.benchmarks.common. Its SHA-256 helper is
supplied locally; production store/contracts/matched helper bodies are intact.
"""
from __future__ import annotations
import ast
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys
import types

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "submission/current_repo"
OUT = Path(__file__).resolve().parent
for name, relative in (
    ("galp", "galp"), ("galp.benchmarks", "galp/benchmarks"),
    ("galp.benchmarks.dct_baselines", "galp/benchmarks/dct_baselines"),
    ("galp.benchmarks.dct_models", "galp/benchmarks/dct_models"),
):
    module = types.ModuleType(name)
    module.__path__ = [str(REPO / relative)]
    sys.modules[name] = module
common = types.ModuleType("galp.benchmarks.common")
common.sha256_file = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.modules[common.__name__] = common
contracts = importlib.import_module("galp.benchmarks.dct_baselines.contracts")
store = importlib.import_module("galp.benchmarks.dct_baselines.store")
matched = importlib.import_module("galp.benchmarks.dct_models.matched_training")

# Execute original window function on the actual submitted traces.
training_path = REPO / "galp/benchmarks/dct_baselines/training.py"
tree = ast.parse(training_path.read_text())
namespace = {}
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                             and node.name == "update_windows"], type_ignores=[]), str(training_path), "exec"), namespace)
trace_results = {}
image_sets = []
for name in ("calibration_trace", "trace"):
    path = ROOT / f"submission/evidence/prepared/contract/{name}.jsonl"
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    windows = namespace["update_windows"](rows, 16)
    ids = {row["image_id"] for row in rows}
    image_sets.append(ids)
    trace_results[name] = dict(
        occurrences=len(rows), unique_images=len(ids),
        microbatch_sizes=[sum(row["microbatch_id"] == i for row in rows)
                          for i in sorted({row["microbatch_id"] for row in rows})],
        update_samples=[len(w) for w in windows],
        update_microbatches=[len({row["microbatch_id"] for row in w}) for w in windows],
        crop_boxes=len({tuple(row["crop_box"]) for row in rows}),
    )

# Confirm the deliberately limited declaration/schedule matching behavior.
# training_identity() cannot run from this partial export because it refers to
# omitted training_audit_policy.py. Construct explicit fixture identities only;
# check_pair itself is executed unchanged.
identity = {name: "fixture" for name in (
    "source_manifest mapping_sha256 condition seed crop_policy order_policy profile channels grid "
    "initial_model_hash recipe precision tf32 compile compile_mode microbatch accumulation pool_images "
    "epochs max_pools data_only runtime augmentation resumed short_warmup audit_policy model_code training_driver"
).split()}
identity.update(condition="B6", initial_model_hash="fixed-initial-state", data_only=False,
                resumed=False, runtime={"device": "H100", "device_uuid": "fixed"})
left = dict(matched_identity=identity, matched_identity_sha256=store.fingerprint(identity), epochs=[
    dict(epoch=0, samples=4096, unique_samples=4096, full_epoch=False, optimizer_updates=4,
         sample_order_digest="frozen-order", pools=[dict(pool_index=0, images=4096)], seconds=10.0)])
pair_results = {"same": matched.check_pair(left, copy.deepcopy(left))}
for name, field, value in (("condition", "condition", "A0"),
                           ("initial_state", "initial_model_hash", "other"),
                           ("runtime", "runtime", {"device_uuid": "other"})):
    right = copy.deepcopy(left)
    right["matched_identity"][field] = value
    right["matched_identity_sha256"] = store.fingerprint(right["matched_identity"])
    try:
        matched.check_pair(left, right)
    except ValueError as exc:
        pair_results[name] = {"rejected": str(exc)}
    else:
        raise AssertionError(name)
right = copy.deepcopy(left)
right["epochs"][0]["sample_order_digest"] = "other-order"
try:
    matched.check_pair(left, right)
except ValueError as exc:
    pair_results["consumed_order"] = {"rejected": str(exc)}
else:
    raise AssertionError("order")

# Show that training_store_identity binds metadata paths/labels, not actual JPEG
# content. The store manifest remains unchanged; the source JPEG is changed at
# the same path. This is a scope gap, not a corrupt-NPZ/preflight bypass.
fixture = OUT / "source_identity_fixture"
fixture.mkdir(exist_ok=True)
jpeg = fixture / "source.jpg"
Image.new("RGB", (512, 512), (128, 128, 128)).save(jpeg, quality=75, subsampling=2)
initial_sha = common.sha256_file(jpeg)
with Image.open(jpeg) as im:
    tables = tuple(np.array(im.quantization[q], dtype=np.uint16).reshape(8, 8) for q in (0, 1, 1))
metadata = dict(image_id="sample", label=0, split="train", block_size=8,
    width=512, height=512, path=str(jpeg.resolve()), jpeg_sha256=initial_sha,
    components=[dict(component_id=i, block_grid=list(g)) for i, g in enumerate(((64,64),(32,32),(32,32)))])
image = contracts.SourceImage(metadata,
    tuple(np.zeros((*g, 8, 8), dtype=np.int16) for g in ((64,64),(32,32),(32,32))), tables)
source_ref = {"path": "fixture-source.json", "sha256": "fixture"}
store_root = fixture / "store"
store.build_store([image], store_root, "ic_matched_shared", source_artifact=source_ref)
records = [("sample", 0, jpeg)]
before = store.training_store_identity(store_root, records)
Image.new("RGB", (512, 512), (96, 96, 96)).save(jpeg, quality=75, subsampling=2)
changed_sha = common.sha256_file(jpeg)
after = store.training_store_identity(store_root, records)
assert changed_sha != initial_sha and before == after
with store.StoreReader(store_root) as reader:
    preflight = reader.verify_content()
result = dict(
    execution_scope="Original NumPy store/contracts and pure matched/window helpers; SHA helper shim only; no Torch/CUDA execution",
    trace=trace_results, calibration_verification_image_overlap=len(image_sets[0] & image_sets[1]),
    matched_pair=pair_results,
    source_identity_scope=dict(changed_jpeg_same_path_accepted=True, before_sha256=initial_sha,
        after_sha256=changed_sha, same_returned_identity=before == after, store_content_preflight=preflight,
        interpretation="Existing formal helper checks population/labels/paths/masks/store bytes. A full common-source numerical/content gate must additionally establish current JPEG/FastLens/store coefficient equality."))
(OUT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"trace": {k: {a: v for a, v in value.items() if a != 'microbatch_sizes'} for k, value in trace_results.items()},
    "disjoint": not (image_sets[0] & image_sets[1]), "matched_pair_checks": list(pair_results),
    "changed_jpeg_same_path_accepted": True}, indent=2))
