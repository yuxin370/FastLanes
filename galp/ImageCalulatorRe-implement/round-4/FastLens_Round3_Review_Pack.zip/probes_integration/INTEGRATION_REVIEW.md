# Round3 集成与数值证据范围审查

审查对象：`/workspace/scratch/22ddd5f2b436/review_round3_20261010/submission`。

以下源码相对路径均以 `submission/current_repo/` 为根。审查只读产品代码；本地执行了 NumPy 存储与纯 Python helper，没有重新运行 Torch、CUDA、完整训练或完整父仓库。附件中的 GPU 结果均是提交者提供的记录。

## 1. 总体判断

当前实现已经符合“接入 IC/FS 存储，复用现有模型和训练流程”的主要结构。M1 有专用同条件 launcher 和配对检查，M2 的数值 fixture 也确实补足了真实图片、batch64、真实 accum16 和尾部更新。但这些进展尚不能视为固定预训练 checkpoint 的推理验收，也不能代替正式多 worker、完整输入管线的性能和资源验收。

此外，IC/FS 和 FastLens 共用模型输入语义，并非共用所有变换的执行实现。当前结果适合解释为相同模型输入合同下的输入管线比较。若要将差异严格归因于磁盘格式，还需要共同的 raw q/Q 接口及相同的后续几何执行层。

## 2. 存储接入实际复用了哪些部分

### CNN

`galp/benchmarks/dct_models/training_jpeg.py`：

- 第87–124行：`StoreDctDataset` 继承既有 `JpegDctDataset`。
- 第96–110行：对实际 DataLoader 微批合并计划和读取，替换 coefficient acquisition。
- 第117–120行：q×Q 后调用既有 `self.transform(...)`。
- 第59–84行：CPU spectral resize、频率选择、flip 等几何操作沿用 JPEG reference 的 transform。
- 第147–149、182行：复用既有 GPU `ProjectedDctTrainingAugment`。
- 模型、optimizer、scheduler、更新循环、验证与报告继续使用 `galp/benchmarks/dct_models/training_pls.py`。

### Transformer

`galp/benchmarks/system_rgbnomore/training/pipeline.py`：

- 第459–470行：同一个 `_RgbNoMoreDctDataset` 接收可选 `baseline_store`。
- 第513–542行：对实际微批合并存储读取。
- 第538–539行：存储分支调用既有 `_transform`。
- 第553–594行：q×Q、crop、resize、normalize 共用。
- `galp/benchmarks/training_pls/train.py` 第2117–2160行：沿用共同的 GPU RandAugment、Mixup、模型和训练更新。

### 与 FastLens CUDA 路径的边界

`galp/benchmarks/dct_baselines/unified.py` 第188–193行的 IC/FS 分支先在 CPU materialize，再传到 device；第194–219行的 FastLens 分支调用 native CUDA `DirectDctPipeline`。

因此当前适配复用了既有 JPEG/reference 几何代码和共同训练部分，并没有让 IC/FS 与 FastLens 的所有几何操作调用同一个 CUDA 实现。要做纯存储归因，可在 raw q/Q + geometry metadata 处建立共同接口；共同 GPU 变换可以复用，但 IC/FS 的 packing、格式转换、H2D 等成本仍必须计入。这种配置应明确标为共同执行层下的存储适配比较。

## 3. M1：专用 matched launcher 与配对检查

`galp/benchmarks/dct_models/matched_training.py` 第69–94行，专用 launcher 运行 JPEG/native/IC/IC-b/FS 时都传 `--condition B6`，使用4096图 pool。

第38–64行的 `check_pair` 检查：

- source manifest、mapping、condition、seed、crop/order policy；
- model/profile/grid/channels、initial model hash；
- recipe、precision、TF32、compile、microbatch、accumulation、pool；
- runtime GPU UUID、CUDA、binding 等身份；
- 实际 epoch、samples、unique samples、optimizer updates、sample order digest、pool 顺序与大小。

缺身份的 legacy 结果、data-only 和 resume 不被当作严格 paired speedup。函数输出仍为 `headline_eligible=False`，并说明生产 numerical/global-resource gate 尚需另行满足。

独立 probe 执行了原始 `check_pair`，相同 fixture 通过；condition、initial-model hash、runtime 和实际消费顺序的变化分别被拒绝。由于导出包没有 `training_audit_policy.py`，直接运行 `training_identity()` 会缺文件；probe 使用手工 fixture identity 测试配对函数，不将这部分宣称为真实训练身份生成验收。

### 已有实验兼容性

`galp/benchmarks/dct_models/cnn_training_baselines.sh` 第48–58行仍保留 JPEG/IC/FS 为 A0、native 为 B6 的既有实验。新 matched launcher 独立存在，是合理的兼容安排。旧 launcher 的结果仍不应被当作严格 matched pair。

当前静态材料不足以宣称所有既有实验完全无回归；尤其 CUDA 核心改动还应按其自身影响范围验证。

## 4. M2：真实 accumulation 与 tail 已独立复核

`galp/benchmarks/dct_baselines/production_gate.py` 第59–80、149–163行定义8194图数值 fixture：

| 分区 | 图片位置 | 唯一样本数 | 微批结构 | 更新样本数 |
|---|---|---:|---|---|
| calibration | 0–4095，再加8192 | 4097 | 64个64图批 + 1个1图批 | 1024、1024、1024、1024、1 |
| verification | 4096–8191，再加8193 | 4097 | 64个64图批 + 1个1图批 | 1024、1024、1024、1024、1 |

对两个附件原始 trace 执行原始 `training.update_windows` 后，上述数量成立；两阶段 image ID 交集为0；每次更新的微批数为 `[16,16,16,16,1]`。这解决了上一轮 accumulation=16 但实际每次只累积一个微批的问题。

数值 gate 的代码意义：

- G1：独立 JPEG/reference 与 store/native 的 q、Q、组件几何比较。
- G2：backend 最终输入与独立 CPU geometry/oracle finishing 比较，soft targets 单独精确比较。
- G3：相同模型、optimizer、decay、scheduler、RNG 初态下的成对训练。

实现位置是 `galp/benchmarks/dct_baselines/gates.py` 第147–226行，以及第67–97行 `paired_updates`。零误差字段有实际比较代码支撑，不能仅因它们是 JSON 就一概否定；但也不能只读 `passed` 就推断整个实验完成。

### 生产大小数值 fixture 与正式生产管线的区别

`UnifiedReplay.raw` 第194–219行每次对当前一个微批调用 `DirectDctPipeline.start([ids])`；它不是正式 `DirectDctPlsPipeline` 的连续多 pool、slot 和生命周期执行。`gates.py` 第196–214行先把实际与参考输入保存在字典，再执行成对训练，也不是吞吐路径。

因此它尚未测正式 PyTorch multiworker 生命周期、未消费 lookahead、全局 CPU/内存/I/O；数值程序墙钟不能充当吞吐。

另外，前四个 backend 与 FS 记录中的 `unified.py` 哈希不同，前四项的精确旧源码快照缺失。只能按各自记录的版本解释成功证据，不能宣称当前单一版本已取得全部五项验收。

## 5. 当前成功记录不是固定预训练 checkpoint 推理验收

附件 `evidence/prepared/contract/profile.json` 明确写明：

```json
"checkpoint_role": "inference reference only; training starts from the separately hashed complete snapshot"
```

相应代码行为：

- `galp/benchmarks/dct_baselines/unified.py` 第240–247行：CNN 模型加载后重置每个带参数 module。
- Transformer 调用 `galp/benchmarks/system_rgbnomore/training/model_factory.py` 的 `build_model`；第215–235行创建 ViT 并进入 train 模式，没有在此加载所给推理 checkpoint。
- `galp/benchmarks/dct_models/training_pls.py` 第198–212行明确重置 checkpoint 参数，并记录 scratch initial-model hash。
- `gates.create_snapshot` 第20–35行保存的是上述 training snapshot。

这是既定训练数值 gate 的合理设置，但不能将其描述为已有预训练模型的 logits、预测、准确率均已验证。

按用户当前澄清的目标，后续优先工作应是：固定实际预训练 checkpoint、既有 inference profile 和验证 trace，检查 IC/FS adapter 的最终输入、logits/预测与准确率，再测正式 E2E。为了固定表示的存储比较，IC native optimizer 不必作为先决条件继续扩大实现范围。

## 6. 正式 source identity 的一个复现范围缺口

`galp/benchmarks/dct_baselines/store.py` 第30–46行 `training_store_identity` 检查 IDs、labels、JPEG source path、all64 masks 和 store 自身身份，但没有核对当前 JPEG bytes/hash 与存储 metadata 中的 `jpeg_sha256`。

独立 probe 的过程：

1. 建立一个合法512×512灰色JPEG，以及记录该路径和哈希的matched store。
2. 在同一路径把JPEG替换为另一张合法灰色JPEG。
3. 原始 `training_store_identity` 返回的身份不变。
4. `reader.verify_content()` 也通过；它正确验证的是NPZ payload，而不是外部JPEG。

这个反例不推翻附件已做的 G1 数值检查。它表明正式 M1 的 `matched` 只保证声明和消费计划一致，不能单独建立当前JPEG、FastLens与NPZ存储的共同源身份。

最小处理办法是在正式结果成为headline前，绑定已有G1/common-source fingerprint；或在既有source preflight中比较当前source fingerprint与store metadata的JPEG hashes。无需新增复杂证明框架。

CNN正式入口的 `--baseline-evidence` 是可选的；提供时主要核对store/model名，`galp/benchmarks/dct_models/training_pls.py` 第145–160行。该入口自身不替代完整formal GPU trace的对照。

## 7. 当前计量的可接受范围

### 已修复的缓存描述

- `galp/benchmarks/training_pls/train.py` 第1656–1659行：cache residency unmeasured，IC/FS epoch1为post-verification/order diagnostic，epoch2不保证warm。
- CNN `galp/benchmarks/dct_models/training_pls.py` 第505–509行也明确相同限制。

上一轮关于这些输出仍误标cold的批评可以关闭。

### 尚待正式性能验收

- Transformer第2410–2412行明确计数只覆盖 consumed microbatches 与worker初始化；unused lookahead未计量。
- CNN第430–437、500–504行只在pool边界采样process-tree RSS；相加会重复计算shared pages；`RUSAGE_CHILDREN`不是整管线瞬时峰值。
- CNN `training_jpeg.py` 第99–103行、Transformer `pipeline.py` 第519–522行，每个DataLoader worker独立reader，cache为0。
- 全局CPU/reader内存预算、跨worker共享、完整生命周期I/O、相同资源下合理调参仍需验证。

附件没有给出正式公平性能结论，应把这些列为主表之前的待验收事项，而不是指控既有性能数字不实。

## 8. Output-ready 映射问题的具体作用范围

CUDA审查中的CPU调度反例确认：物理排序后的descriptor编号被当作原始output slot分组，可能给乱序/重复请求的错误输出批提前安排finalize和ready event。该问题在base版本已有，不能归因于本轮down2数值修复。

### 8.1 正式 PLS 训练没有启用该分支

不能将“pool4096、microbatch64”直接等同于 `output_batch_images=64`。

- `galp/torch/direct_dct_pls_torch.cpp` 第513–556行设置 `options.schedule.microbatch_images`，没有设置 `options.device.output_batch_images`。
- `galp/include/galp/profiles/direct_dct.hpp` 第57–82行的 `materialize_direct_dct_options` 同样未设置它。
- `galp/include/galp/jpeg_dct_device.hpp` 第221行默认 `output_batch_images=0U`。
- `galp/src/jpeg/jpeg_dct_device.cu` 第6727–6737行只有 output_batch_images非零、projection非空、输出FP32时才创建分批ready events。
- `galp/src/api/direct_dct_pls_postprocess.cu` 第671–673行明确等待完整 `source.cuda_completion_event()`，再做PLS后处理。

因此目前不能宣称该反例证明正式PLS训练输出受损。

### 8.2 既有 CNN inference benchmark 有该配置，但通常是物理顺序

`galp/benchmarks/dct_models/evaluate_shards.py`：

- 第99行：model batch默认64。
- 第72–80、112行：activation由1/2/4个shard构成，可为1024/2048/4096图，图片ID按物理位置递增。
- 第199–204行：非verify的projected运行设置 `output_batch_images=args.batch_size`。
- 第279–295行：消费 `projected_range(...)` 后执行模型。

实际验证缺口是第199行：`--verify` 会关闭 `streamed_projection`，因此该verify路径不验证性能路径的分批projection完成调度。

不过该脚本通常按物理递增ID请求，descriptor与output_slot的分组一致，可能掩盖映射错误；不能据CPU反例断言既有脚本结果已被污染。

### 8.3 公共 CNN API 允许所需的乱序/重复大请求

`galp/torch/direct_dct.py`：

- 第436–441行：CNN pipeline设置 `output_batch_images=batch_size`。
- 第457–488行：接受调用者的完整preparation batches。
- 第373–379行：只切分输出视图，不切分preparation requests。
- 第347–358行：输出视图调用native `projected_range`。

`galp/torch/direct_dct_torch.cpp` 第1819–1836行的 `projected_range` 按image event等待，再返回对应输出范围。因此大于model batch、乱序或重复的CNN preparation batch存在相关配置入口。

仍需保留一个wrapper限制：`galp/src/api/direct_dct.cpp` 第536–539行中，`logical_`聚合包装会让 `cuda_image_completion_event` 返回全logical-batch completion；`direct_dct_torch.cpp` 第3343–3345行使用 `Backend::kNativeLogical`。导出包缺相关 `native_logical_batch_pipeline.hpp`，不能完整确认每种包装是否让consumer等待全批。即使consumer等待全批，错误的提前finalize对后续累加是否造成影响也需GPU测试，不能仅靠等待范围断定消失。

### 8.4 当前数值 gate 未覆盖该分支

`dct_baselines/unified.py` 第194–219行对每个最多64图微批调用一次 `self.pipeline.start([ids])`。若输出batch也是64，整个请求只有一个输出批，不会暴露跨输出批映射问题。

附件成功记录实际还是ViT-Ti非projected profile，更没有启用CNN分批projection分支。

### 8.5 最小验收要求

在同一分批projection执行路径中，增加大于model batch的乱序、重复、跨worksetGPU回归，确保finalize和完成事件按原始output slot归属安排。当前只能报告CPU调度反例和对应代码问题；没有实测证据证明附件H100成功记录发生了这种损坏。

## 9. 建议推进顺序

1. 保留当前storage adapter和正式训练接入，冻结用于下一轮验收的代码。
2. 以用户实际已训练checkpoint及既有推理profile做共同source/trace数值对照。
3. 对计划使用的CNN分批projection路径修复并验证output-slot完成映射，避免verification与performance走不同分支。
4. 在正式输入管线测E2E与完整生命周期I/O、全局CPU/内存。
5. 将IC native optimizer标为完整IC系统比较的另一个任务；固定表示的storage baseline不以它完成为前提。

## 10. 本地复核文件

- `probe_integration.py`：原始window函数、原始check_pair、source identity范围反例。
- `results.json`：trace计数、分区交集、配对拒绝结果、源文件同路径变化被接受的结果。
- `source_identity_fixture/`：probe产生的JPEG与NPZ小fixture。

`galp.benchmarks.common` 未附入导出包，probe只为它提供标准SHA-256文件helper；存储和合同函数体未修改。配对检查使用明确的手工fixture身份。没有伪造GPU执行或完整仓库通过记录。
