"""Read-only probes: extracted C++ planner functions and CPU FP32 algebra.

This does not compile the product, execute CUDA, or reconstruct missing image bytes.
The extracted functions run with reduced data-only structs exposing their used fields.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
SUBMISSION = ROOT.parent / "submission"
SRC = SUBMISSION / "current_repo/galp/src/jpeg"


def extract(name):
    text = (SRC / "jpeg_dct_planner.cpp").read_text()
    name_start = text.index("detail::" + name + "(")
    # The return type is supplied explicitly by the harness.
    start = text.index("(", name_start)
    brace = text.index("{", start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return name + text[start:end]


types = r'''
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <random>
#include <set>
#include <stdexcept>
#include <utility>
#include <vector>
struct Component { uint8_t present=1; uint16_t x_up_factor=1,y_up_factor=1,x_down_factor=2,y_down_factor=2; };
struct Image { std::array<Component,3> components; };
struct JpegDctDeviceBlockMajorPlanlessPlan { std::vector<Image> images; };
struct JpegDctGridTransformSpec { uint32_t y_output_width_blocks=2,y_output_height_blocks=1,cbcr_output_width_blocks=1,cbcr_output_height_blocks=1; };
struct JpegDctDeviceActiveOutputGroup { uint64_t block_begin; uint32_t block_count,image_begin,image_count; uint64_t task_begin=0; };
struct JpegDctDeviceBlockMajorActiveOutputSchedule {
 std::vector<uint64_t> offsets;
 std::vector<uint32_t> active_output_blocks;
 uint32_t repeated_image_count=1;
 std::vector<JpegDctDeviceActiveOutputGroup> groups;
 std::vector<uint64_t> group_offsets;
 std::vector<uint32_t> image_indices;
 uint64_t logical_output_block_count=0;
};
struct JpegDctSplitDown2Block { uint32_t slot=UINT32_MAX,last_workset=UINT32_MAX; };
struct JpegDctSplitDown2Plan { std::vector<JpegDctSplitDown2Block> blocks; size_t source_value_count=0; };
struct JpegDctOutputReadyPoint { uint64_t task_end; size_t output_batch; };
namespace detail { using ::JpegDctOutputReadyPoint; }
'''

harness = r'''
std::vector<std::vector<uint32_t>> expand(const JpegDctDeviceBlockMajorActiveOutputSchedule& s,uint64_t bpi){
 std::vector<std::vector<uint32_t>> x(s.offsets.size()-1);
 for(size_t w=0;w<x.size();++w){
  if(s.groups.empty()){
   for(uint32_t im=0;im<s.repeated_image_count;++im)
    for(auto k=s.offsets[w];k<s.offsets[w+1];++k)x[w].push_back(im*bpi+s.active_output_blocks[k]);
  } else {
   for(auto k=s.group_offsets[w];k<s.group_offsets[w+1];++k){
    const auto& g=s.groups[k];
    for(uint32_t im=0;im<std::max(g.image_count,1U);++im)
     for(uint32_t i=0;i<g.block_count;++i)x[w].push_back((g.image_count?s.image_indices[g.image_begin+im]*bpi:0)+s.active_output_blocks[g.block_begin+i]);
   }
  }
 }
 return x;
}
void check(const JpegDctDeviceBlockMajorActiveOutputSchedule& s,const JpegDctDeviceBlockMajorPlanlessPlan& p,const JpegDctGridTransformSpec& t){
 uint64_t y=uint64_t(t.y_output_width_blocks)*t.y_output_height_blocks,c=uint64_t(t.cbcr_output_width_blocks)*t.cbcr_output_height_blocks,bpi=y+2*c;
 auto x=expand(s,bpi);
 std::vector<std::set<uint32_t>> owners(s.logical_output_block_count);
 for(uint32_t w=0;w<x.size();++w){std::set<uint32_t> once;
  for(auto b:x[w]){assert(b<owners.size());assert(once.insert(b).second);owners[b].insert(w);}
 }
 auto got=build_split_down2_plan(s,p,t);size_t expected=0;std::set<uint32_t> slots;
 for(size_t b=0;b<owners.size();++b){auto local=b%bpi;auto comp=local<y?0U:1U+(local-y)/c;const auto& q=p.images[b/bpi].components[comp];
  bool down=q.present&&q.x_up_factor==1&&q.y_up_factor==1&&q.x_down_factor>=1&&q.y_down_factor>=1&&q.x_down_factor<=2&&q.y_down_factor<=2&&q.x_down_factor*q.y_down_factor>1;
  bool split=down&&owners[b].size()>1;expected+=split;
  if(!got.blocks.empty()){
   auto v=got.blocks[b];assert((v.slot!=UINT32_MAX)==split);
   if(split){assert(slots.insert(v.slot).second);assert(v.last_workset==*owners[b].rbegin());}
  }
 }
 assert((expected==0)==got.blocks.empty());assert(got.source_value_count==expected*256);
 if(!slots.empty()){assert(*slots.begin()==0);assert(*slots.rbegin()+1==expected);}
 for(size_t batch=1;batch<=p.images.size()+1;++batch){
  auto ready=build_output_batch_completion_schedule(s,bpi,p.images.size(),batch);
  std::vector<std::pair<size_t,uint64_t>> reference((p.images.size()+batch-1)/batch,{x.size(),0});
  for(size_t w=0;w<x.size();++w)for(size_t k=0;k<x[w].size();++k){size_t bi=x[w][k]/bpi/batch;reference[bi]={w,k+1};}
  std::vector<bool> seen(reference.size(),false);
  for(size_t w=0;w<ready.size();++w)for(auto r:ready[w]){assert(!seen[r.output_batch]);seen[r.output_batch]=true;assert(reference[r.output_batch]==std::make_pair(w,r.task_end));}
  for(size_t b=0;b<reference.size();++b)assert(seen[b]==(reference[b].first!=x.size()));
 }
}
constexpr float conv[128]={
MATRIX
};
std::array<float,64> transform(const std::array<float,256>& a,uint32_t xd=2,uint32_t yd=2){
 std::array<float,128> v{};std::array<float,64> z{};const auto width=xd*8;
 for(uint32_t y=0;y<8;++y)for(uint32_t x=0;x<width;++x){float sum=0;
  if(yd==1)sum=a[y*width+x];else for(uint32_t i=0;i<16;++i)sum=std::fma(conv[y*16+i],a[i*width+x],sum);
  v[y*width+x]=sum;
 }
 for(uint32_t y=0;y<8;++y)for(uint32_t x=0;x<8;++x){float sum=0;
  if(xd==1)sum=v[y*width+x];else for(uint32_t i=0;i<16;++i)sum=std::fma(v[y*width+i],conv[x*16+i],sum);
  z[y*8+x]=xd*yd==4?sum*0.5F:xd*yd==2?sum/0x1.6a09e60000000p+0F:sum;
 }
 return z;
}
int main(){
 std::cout.precision(17);
 std::mt19937 rng(20261010);size_t cases=0;
 for(int mode=0;mode<3;++mode)for(int trial=0;trial<400;++trial){
  uint32_t n=1+rng()%8,nw=1+rng()%8;JpegDctGridTransformSpec t;t.y_output_width_blocks=1+rng()%5;t.y_output_height_blocks=1+rng()%3;t.cbcr_output_width_blocks=1+rng()%3;
  uint64_t bpi=t.y_output_width_blocks*t.y_output_height_blocks+2*t.cbcr_output_width_blocks*t.cbcr_output_height_blocks;
  JpegDctDeviceBlockMajorPlanlessPlan p;p.images.resize(n);
  for(auto& im:p.images)for(auto& c:im.components){auto k=rng()%5;c.present=k!=0;c.x_up_factor=k==1?2:1;c.x_down_factor=k==2?1:2;c.y_down_factor=k==3?1:2;}
  JpegDctDeviceBlockMajorActiveOutputSchedule s;s.logical_output_block_count=n*bpi;s.offsets={0};
  if(mode==0){ // Absolute slices.
   for(uint32_t w=0;w<nw;++w){for(uint32_t b=0;b<n*bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(b);s.offsets.push_back(s.active_output_blocks.size());}
  }else if(mode==1){ // Shared relative slices with repeated occurrences.
   s.repeated_image_count=n;
   for(uint32_t w=0;w<nw;++w){for(uint32_t b=0;b<bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(b);s.offsets.push_back(s.active_output_blocks.size());}
  }else{ // Groups alternate absolute and relative subsets, shuffled occurrence order.
   s.group_offsets={0};
   for(uint32_t w=0;w<nw;++w){std::vector<uint32_t> ids(n);for(uint32_t j=0;j<n;++j)ids[j]=j;std::shuffle(ids.begin(),ids.end(),rng);uint64_t task=0;
    for(uint32_t start=0;start<n;){uint32_t count=1+rng()%(n-start);bool relative=(rng()%2)!=0;uint64_t begin=s.active_output_blocks.size();uint32_t image_begin=s.image_indices.size();
     if(relative){for(uint32_t b=0;b<bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(b);for(uint32_t j=0;j<count;++j)s.image_indices.push_back(ids[start+j]);}
     else {for(uint32_t j=0;j<count;++j)for(uint32_t b=0;b<bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(ids[start+j]*bpi+b);}
     uint32_t block_count=s.active_output_blocks.size()-begin;if(block_count)s.groups.push_back({begin,block_count,image_begin,relative?count:0,task});task+=uint64_t(block_count)*(relative?count:1);start+=count;
    }
    s.group_offsets.push_back(s.groups.size());s.offsets.push_back(s.active_output_blocks.size());
   }
  }
  check(s,p,t);++cases;
 }
 // Emulate gather ownership and the published scalar FP32 FMA pass order.
 size_t algebra_cases=0,gather_equal=0,old_integer_mismatch=0;float max_old_float_error=0;bool have_example=false;
 float example_full=0,example_old=0;
 for(uint32_t xd=1;xd<=2;++xd)for(uint32_t yd=1;yd<=2;++yd)if(xd*yd>1)for(int trial=0;trial<501;++trial){
  std::array<float,256> src{},saved{},parts[4]{};
  for(uint32_t y=0;y<yd*8;++y)for(uint32_t x=0;x<xd*8;++x){size_t i=y*(xd*8)+x;src[i]=float(int(rng()%101)-50);parts[(y/8)*xd+x/8][i]=src[i];}
  auto full=transform(src,xd,yd);std::array<float,64> old{};
  for(uint32_t w=0;w<xd*yd;++w){auto partial=transform(parts[w],xd,yd);for(int i=0;i<64;++i)old[i]+=partial[i];for(uint32_t y=0;y<yd*8;++y)for(uint32_t x=0;x<xd*8;++x)if((y/8)*xd+x/8==w)saved[y*(xd*8)+x]=src[y*(xd*8)+x];}
  auto after=transform(saved,xd,yd);assert(std::memcmp(after.data(),full.data(),sizeof(after))==0);++gather_equal;++algebra_cases;
  for(int i=0;i<64;++i){max_old_float_error=std::max(max_old_float_error,std::abs(old[i]-full[i]));if(std::nearbyint(old[i])!=std::nearbyint(full[i])){++old_integer_mismatch;if(!have_example){have_example=true;example_full=full[i];example_old=old[i];}}}
 }
 // Padding with a legal positive-only clamp exposes the zero-initialization boundary.
 std::array<float,256> padded_reference{},padded_saved{};
 for(size_t y=0;y<16;++y)for(size_t x=0;x<16;++x){size_t i=y*16+x;bool in_bounds=x<8;padded_reference[i]=in_bounds?float(10+(i%3)):10.0F;padded_saved[i]=in_bounds?padded_reference[i]:0.0F;}
 auto padded_expected=transform(padded_reference),padded_actual=transform(padded_saved);size_t padding_different=0;
 for(int i=0;i<64;++i)padding_different+=std::nearbyint(padded_expected[i])!=std::nearbyint(padded_actual[i]);
 // Actual compact planning sorts descriptors physically but preserves their
 // original request_index. The completion function only sees descriptor IDs.
 JpegDctDeviceBlockMajorActiveOutputSchedule inverse;
 inverse.offsets={0,4,8};inverse.active_output_blocks={0,1,2,3,4,5,6,7};inverse.logical_output_block_count=8;
 auto wrong_ready=build_output_batch_completion_schedule(inverse,4,2,1);
 size_t reported_output0_workset=99;
 for(size_t w=0;w<wrong_ready.size();++w)for(auto point:wrong_ready[w])if(point.output_batch==0)reported_output0_workset=w;
 // Descriptor 0 has request_index=1; descriptor 1 has request_index=0.
 size_t actual_output0_last_writer_workset=1;
 assert(reported_output0_workset==0);
 std::cout<<"{\"planner_cases\":"<<cases<<",\"completion_checked_with_multiple_batch_sizes_for_identity_request_mapping\":true,\"cpu_algebra_cases\":"<<algebra_cases<<",\"gather_equal\":"<<gather_equal<<",\"old_partial_integer_mismatches\":"<<old_integer_mismatch<<",\"max_old_float_error\":"<<max_old_float_error<<",\"example_full\":"<<example_full<<",\"example_old\":"<<example_old<<",\"positive_only_clamp_padding_different\":"<<padding_different<<",\"inverse_request_reported_output0_ready_workset\":"<<reported_output0_workset<<",\"inverse_request_actual_output0_last_writer_workset\":"<<actual_output0_last_writer_workset<<"}\n";
}
'''

ROOT.mkdir(parents=True, exist_ok=True)
cpp = ROOT / "planner_and_algebra_probe.cpp"
cpp.write_text(types + "\nJpegDctSplitDown2Plan " + extract("build_split_down2_plan") +
               "\nstd::vector<std::vector<JpegDctOutputReadyPoint>> " +
               extract("build_output_batch_completion_schedule") +
               harness.replace("MATRIX", (SRC / "jpeg_dct_reference_down2.inc").read_text()))
exe = ROOT / "planner_and_algebra_probe"
compile_run = subprocess.run(["c++", "-std=c++20", "-O2", "-Wall", "-Wextra", str(cpp), "-o", str(exe)], capture_output=True, text=True)
(ROOT / "compile.log").write_text(compile_run.stdout + compile_run.stderr)
compile_run.check_returncode()
run = subprocess.run([str(exe)], capture_output=True, text=True)
(ROOT / "probe.log").write_text(run.stdout + run.stderr)
run.check_returncode()
result = json.loads(run.stdout)
result.update({"gpu_executed": False, "full_product_compiled": False,
               "scope": "Exact extracted planner functions using reduced data-only structs; independent ownership and completion oracle; CPU std::fma emulation using current conversion constants.",
               "planner_source_sha256": hashlib.sha256((SRC / "jpeg_dct_planner.cpp").read_bytes()).hexdigest(),
               "harness_sha256": hashlib.sha256(cpp.read_bytes()).hexdigest()})
(ROOT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
