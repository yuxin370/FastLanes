# Round 3 native CUDA review

## Scope and verification boundary

This is a read-only review of `submission/current_repo`, the corresponding `base_HEAD`, and `patches/01_recent_cuda_fix.diff`. No product code was changed. No CUDA runtime, PyTorch execution, original ImageNet bytes, native binary, or complete parent build is available in this probe. The supplied H100 logs/JSON are submitted execution evidence, not executions independently performed here.

`run_probes.py` extracts the **exact current** `build_split_down2_plan` and `build_output_batch_completion_schedule` function bodies and compiles them against minimal data-only structs. The independent oracle expands schedule task ownership. The CPU algebra probe uses the submitted hexadecimal FP32 conversion constants and `std::fma`; it demonstrates the proposed rounding mechanism, not a rerun of the missing failing image.

Results in `results.json`:

- 1,200 randomized direct, repeated, and grouped schedules passed split-slot ownership checks, including mixed down2/identity/upsample component descriptors and empty worksets.
- Completion points agree with the oracle when descriptor index equals original output index; each case used multiple output batch sizes.
- 1,503 CPU algebra cases across 1×2, 2×1, and 2×2 downsampling: gathering all source values and then running the same FP32 passes always equals the full-source computation bit for bit.
- The former independently transformed partials produced 1,223 rounded-coefficient differences across those generated cases; one example was full-source `30.500003814697266` versus partial-sum `30.5`. This supports the proposed non-associativity diagnosis.
- A separate two-image inverse request mapping demonstrates a **current output-completion indexing bug** described below.
- A separate legal positive-only clamp plus padding example demonstrates a conditional source-initialization semantic difference, outside the current matched default contract.

## Verdict on the recent numerical fix

The fix is technically coherent and directly addresses the observed half-integer failure. It retains **dequantized, clamped source values**, not already-resized partial outputs. Each output appearing in more than one workset gets one slot, populated by its contributing worksets; the final owner performs the two FP32 transform passes once.

Relevant implementation:

- `jpeg_dct_planner.cpp:715–769`: one slot for each down2 output with more than one workset owner; supports direct, repeated-image and grouped schedules; final owner is the last workset encountered.
- `jpeg_dct_device.cu:2340–2365`: uploads slot metadata and zeroes the used source storage once per batch schedule.
- `jpeg_dct_transform_kernels.cu:939–943,1031–1043`: only resident source blocks overwrite the saved values; nonfinal owners stop before the transform.
- `jpeg_dct_transform_kernels.cu:1044–1122`: existing FP32 transform order and final store preserved.

The default matched clamp includes zero. In that contract, out-of-image positions retain the expected zero padding. Missing source blocks in the **current** workset preserve values gathered earlier. Absent components, identity, upsampling, and outputs whose sources all belong to one workset do not receive a split slot. Different request occurrences retain separate slots even if they refer to the same physical image.

The concurrency/lifetime structure is reasonable:

- Decode-to-transform handoff occurs on an event; all transform calls use the same transform stream (`jpeg_dct_device.cu:4746–4755`).
- Nonfinal workset reuse waits for gather completion (`:4845–4883`), while the final asynchronous tail is protected by the existing execution fence.
- The reader bridge serializes scratch rebinding and joins the earlier execution fence (`jpeg_dct_device_bridge.cpp:40–42,59–70`).
- Scratch is ordinary RAII device allocation, released through `JpegDctDeviceScratchBuffer` (`jpeg_dct_device.cu:1137–1204`); retaining capacity across calls is not evidence of a leak.

No definite race or source-loss bug was found for valid unique-owner schedules, ordinary zero-containing clamps, and the newly targeted down2 path. This is **not** a proof of all CUDA paths. The added unit test checks planning metadata, not device gather, padding, asynchronous handoff, or old/new actual numerical equivalence.

## Findings

### CUDA-01 — P1: early output completion uses physical descriptor index instead of original output slot

**Status:** deterministically demonstrated with the extracted C++ completion function and current producer/consumer mapping; GPU symptom not independently executed. **Pre-existing in base_HEAD**, not introduced by the six-file down2 fix.

Code chain:

1. `jpeg_dct_block_major_plan.cpp:635–653` sorts requests by physical shard/local-image order when needed.
2. `:689–720` constructs `plan.requests` in that order while retaining the original `output_slot`.
3. `jpeg_dct_planner.cpp:2756–2831` constructs device descriptors in physical order; line 2766 sets `image.request_index = source_request.output_slot`.
4. `jpeg_dct_transform_kernels.cu:384,401,409` writes tensor output by `image.request_index`.
5. `build_output_batch_completion_schedule`, `jpeg_dct_planner.cpp:773–825`, divides the **descriptor** image index by `batch_images` at line 784. Direct, repeated and grouped paths all pass descriptor indices.
6. `jpeg_dct_device.cu:5483–5484` calls that function without a descriptor-to-output mapping. At `:2542–2545`, it passes the result to `finish_projected_output_batch`.
7. `finish_projected_output_batch`, `:2081–2106`, finalizes a contiguous **original output** batch in place and records its ready event.

Minimal counterexample: two original requests in inverse physical order produce descriptors with `request_index=[1,0]`. Descriptor 0 is written in workset 0; descriptor 1 is written in workset 1. With `output_batch_images=1`, the function reports output batch 0 ready in workset 0, while its actual last writer runs in workset 1. `results.json` records both values.

Consequences when this mode is active:

- A consumer can be told an output range is ready too early.
- For projected downsampling, finalization can normalize an incomplete accumulator and subsequent worksets can add unnormalized values into it. The final sweep skips ranges already marked complete, so merely waiting for the whole batch does not necessarily repair it.

The mode is enabled for FP32 projected output when `output_batch_images != 0` (`jpeg_dct_device.cu:6727–6737`) and is exposed by `pipeline_batch_options` (`direct_dct_torch.cpp:3296–3370`). If one request list is only one model microbatch, or requests are monotonic, or all logical batches have identical last worksets, the mismatch can be hidden. Whether a particular formal launcher uses the vulnerable combination must be traced separately; do not assert that the submitted ViT numerical gate failed.

**Smallest repair:** pass the descriptor-to-original-output mapping (or the descriptors themselves) to the completion planner and group the final writer by `request_index / output_batch_images`. Preserve physical scheduling and source-gather slots. Add one focused case with inverse/duplicate requests, different contributing worksets, multiple output batches and consumer-stream range access. The existing `[2,0,2]` case in `dct_models/tests/test_online_crop.py:128–145` need not expose this if the requests all share the same workset.

### CUDA-02 — P2: new split-source GPU storage is omitted from the public transient total

**Status:** definite accounting omission by static inspection; actual peak/OOM on submitted hardware not measured here.

- `jpeg_dct_planner.cpp:768` requests `256 * N_split` floats. Thus live logical source storage is `1024 * N_split` bytes; one-axis down2 also reserves a full 256-float slot.
- `jpeg_dct_device.cu:2343–2349` allocates both a device metadata copy and that source array. Scratch capacity uses geometric growth (`:1173–1204`) and persists until reader/scratch destruction.
- The added accounting at `:5389–5401` only includes the **host** block metadata vector (`8 * N_logical_output_blocks` bytes). It does not include the GPU source array or its reserved capacity.
- `ActualTransientMemoryTracker`, `:3161–3183`, totals compressed backing, decode arena, active schedule, and fixed ring buffers. The split-source allocation is not registered in any of those categories.
- `actual_transient_memory_gate_passed` at `:5983–5984` still tests this incomplete total against 512 MiB.
- The public `peak_transient_bytes` metric is populated from that same incomplete field in `direct_dct_torch.cpp:1993,2525`.

The allocation **is** visible in the process/native device allocator totals (`jpeg_dct_device.cu:7123–7152`), so it is incorrect to say all memory reporting is blind to it. The problem is the narrower public transient total/gate and absence of a budget for this new cross-workset residency.

**Smallest repair:** include the split-source logical bytes and actual reserved capacity, with its true lifetime, in the existing tracker/public metric; retain a distinct category so host and device bytes remain interpretable. Decide explicitly whether 512 MiB constrains the entire transient working set or only the decode arena. If it is an entire-transient contract, perform admission using this storage too. Do not build an elaborate new cache solely for review; first measure `N_split` and current capacity on intended pool sizes.

The source array is indexed over all split outputs for an execution, without reusing slots after their last owner. This is a reasonable small numerical repair, but its memory scales with the requested output population rather than solely with one decode workset. It changes the performance/memory envelope and must be measured before claiming a bounded total or reusing old performance numbers.

### CUDA-03 — P3, outside current matched settings: padding assumes clamp(0)=0

**Status:** deterministic kernel-semantic counterexample in CPU algebra; not a reported default-workload failure.

The public transform validator (`jpeg_dct_planner.cpp:1708–1710`) accepts any ordered int16 clamp, including `[10,32767]`. In the nonsplit path, an out-of-image source coefficient becomes `clamp(0)` (`jpeg_dct_transform_kernels.cu:994,1029–1037`). In the split path, the zeroed source array never gets written for such positions, so it remains literal zero (`jpeg_dct_device.cu:2346–2349`, kernel `:1031–1035`).

A 2×2 source footprint with one padded column and the remaining two source blocks in different worksets therefore differs from the corresponding complete-source transform for a positive-only clamp. The probe generated 47 differing rounded coefficients. Standard matched clamps include zero and are unaffected.

**Smallest repair if preserving the full existing API contract:** make the final composed source use `clamp(0)` for genuinely out-of-image positions, while continuing to preserve saved values for in-image positions absent from the current workset. A zero-containing default can retain the current fast path. This is lower priority than the measured default path and its resource accounting.

## Evidence and compatibility

The saved H100 FastLens record reports zero-error verification over 4,097 occurrences and five updates. It records binding `.so` identity `ae9cbaaa0464b1844b494ff0bcc8ca4d03b3d54ed5e14e3211de5714106629b0`, coefficient-bridge identity `97e9a57f34c0da9f929694273f0bce661ec7cda9e67347172a21e5aee69c98d3`, and manifest identity. Those binary files are not attached, so this package cannot independently bind their actual bytes/build contents to the six current native source files. The baseline Python `implementation` list alone is not the native implementation identity.

The six-file correction changes no storage format or checkpoint schema. Existing q/Q stores and checkpoint files remain usable. It changes numerical evaluation for **block-major, planless, cross-workset down2 outputs**. Existing identity/upsampling or single-owner output semantics are outside the correction's target. Other rational/general downsampling paths are not repaired by this patch and should not be declared universally bitwise invariant.

Previous experiments to revisit:

- Rerun targeted exact input/state gates on the affected geometry and a frozen current code/binary version.
- Repeat affected throughput, latency, and transient memory measurements, because the new staging writes, allocation/zeroing, planner traversal and delayed transform alter the execution cost.
- Old convergence/accuracy runs remain results of their historical code version. If a paper presents them as produced by the corrected pipeline, obtain the necessary current-version evaluation/trajectory evidence. Do not automatically rerun every 300-epoch run just because a source file changed; identify the affected pipeline/geometry first.
- For a frozen pretrained checkpoint, no retraining is intrinsically required by this compatibility correction; current pipeline evaluation is the relevant verification.

The highest-value next native test is a small real-source case that forces down2 source blocks across three or four worksets, exercises flips and both one-/two-axis downsampling, repeats a request with a different transform, uses a second consumer stream, and immediately reuses the reader. Add a separate unordered multi-output-batch case for CUDA-01. This is more informative than repeatedly replaying the same already-passing full fixture.
