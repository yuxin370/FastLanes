"""Extract exactly the reviewed attachment into a fresh local submission tree."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import shutil
import stat
import zipfile

EXPECTED = "e1a008b267261ebf562225c43baec7c028f890793bceb2bd98b2a9f6052e6cc6"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("archive", type=Path)
args = parser.parse_args()
archive = args.archive.resolve(strict=True)
h = hashlib.sha256()
with archive.open("rb") as src:
    while chunk := src.read(8 * 1024 * 1024):
        h.update(chunk)
if h.hexdigest() != EXPECTED:
    raise SystemExit("This is not the exact Round-3 ZIP that was reviewed; extraction refused.")
destination = Path(__file__).resolve().parent / "submission"
if destination.exists():
    raise SystemExit("submission already exists; use a fresh extraction directory.")
with zipfile.ZipFile(archive) as z:
    for member in z.infolist():
        path = PurePosixPath(member.filename)
        if path.is_absolute() or ".." in path.parts or "\\" in member.filename:
            raise SystemExit("Unsafe archive member path.")
        if stat.S_ISLNK(member.external_attr >> 16):
            raise SystemExit("Symbolic link member refused.")
    destination.mkdir()
    for member in z.infolist():
        target = destination.joinpath(*PurePosixPath(member.filename).parts)
        if member.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with z.open(member) as src, target.open("xb") as dst:
            shutil.copyfileobj(src, dst)
print("Prepared", destination)
