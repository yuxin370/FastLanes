
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <random>
#include <set>
#include <stdexcept>
#include <utility>
#include <vector>
struct Component { uint8_t present=1; uint16_t x_up_factor=1,y_up_factor=1,x_down_factor=2,y_down_factor=2; };
struct Image { std::array<Component,3> components; };
struct JpegDctDeviceBlockMajorPlanlessPlan { std::vector<Image> images; };
struct JpegDctGridTransformSpec { uint32_t y_output_width_blocks=2,y_output_height_blocks=1,cbcr_output_width_blocks=1,cbcr_output_height_blocks=1; };
struct JpegDctDeviceActiveOutputGroup { uint64_t block_begin; uint32_t block_count,image_begin,image_count; uint64_t task_begin=0; };
struct JpegDctDeviceBlockMajorActiveOutputSchedule {
 std::vector<uint64_t> offsets;
 std::vector<uint32_t> active_output_blocks;
 uint32_t repeated_image_count=1;
 std::vector<JpegDctDeviceActiveOutputGroup> groups;
 std::vector<uint64_t> group_offsets;
 std::vector<uint32_t> image_indices;
 uint64_t logical_output_block_count=0;
};
struct JpegDctSplitDown2Block { uint32_t slot=UINT32_MAX,last_workset=UINT32_MAX; };
struct JpegDctSplitDown2Plan { std::vector<JpegDctSplitDown2Block> blocks; size_t source_value_count=0; };
struct JpegDctOutputReadyPoint { uint64_t task_end; size_t output_batch; };
namespace detail { using ::JpegDctOutputReadyPoint; }

JpegDctSplitDown2Plan build_split_down2_plan(const JpegDctDeviceBlockMajorActiveOutputSchedule& schedule,
                               const JpegDctDeviceBlockMajorPlanlessPlan&         plan,
                               const JpegDctGridTransformSpec&                    transform) {
	JpegDctSplitDown2Plan result;
	if (schedule.offsets.size() <= 2U)
		return result;
	const auto uses_down2 = [](const auto& c) {
		return c.present && c.x_up_factor == 1U && c.y_up_factor == 1U && c.x_down_factor >= 1U &&
		       c.y_down_factor >= 1U && c.x_down_factor <= 2U && c.y_down_factor <= 2U &&
		       c.x_down_factor * c.y_down_factor > 1U;
	};
	if (std::none_of(plan.images.begin(), plan.images.end(), [&](const auto& image) {
		    return std::any_of(image.components.begin(), image.components.end(), uses_down2);
	    }))
		return result;
	const uint64_t y_blocks = uint64_t(transform.y_output_width_blocks) * transform.y_output_height_blocks;
	const uint64_t c_blocks = uint64_t(transform.cbcr_output_width_blocks) * transform.cbcr_output_height_blocks;
	const uint64_t blocks_per_image = y_blocks + 2U * c_blocks;
	result.blocks.resize(schedule.logical_output_block_count);
	uint32_t   slots = 0U;
	const auto visit = [&](uint32_t w, uint64_t block) {
		const auto  local     = block % blocks_per_image;
		const auto  component = local < y_blocks ? 0U : 1U + (local - y_blocks) / c_blocks;
		const auto& c         = plan.images[block / blocks_per_image].components[component];
		if (!uses_down2(c))
			return;
		auto& entry = result.blocks[block];
		if (entry.last_workset != std::numeric_limits<uint32_t>::max() && entry.last_workset != w &&
		    entry.slot == std::numeric_limits<uint32_t>::max())
			entry.slot = slots++;
		entry.last_workset = w;
	};
	for (uint32_t w = 0; w + 1 < schedule.offsets.size(); ++w) {
		if (!schedule.groups.empty()) {
			for (auto g = schedule.group_offsets[w]; g < schedule.group_offsets[w + 1]; ++g) {
				const auto& group = schedule.groups[g];
				for (uint32_t image = 0; image < std::max(group.image_count, 1U); ++image) {
					const uint64_t base =
					    group.image_count == 0U
					        ? 0U
					        : uint64_t(schedule.image_indices[group.image_begin + image]) * blocks_per_image;
					for (uint32_t i = 0; i < group.block_count; ++i)
						visit(w, base + schedule.active_output_blocks[group.block_begin + i]);
				}
			}
		} else {
			for (uint32_t image = 0; image < schedule.repeated_image_count; ++image)
				for (auto i = schedule.offsets[w]; i < schedule.offsets[w + 1]; ++i)
					visit(w, uint64_t(image) * blocks_per_image + schedule.active_output_blocks[i]);
		}
	}
	if (slots == 0U)
		return {};
	result.source_value_count = size_t(slots) * 16U * 16U;
	return result;
}
std::vector<std::vector<JpegDctOutputReadyPoint>> build_output_batch_completion_schedule(const JpegDctDeviceBlockMajorActiveOutputSchedule& schedule,
                                               const uint64_t                                     blocks_per_image,
                                               const size_t                                       image_count,
                                               const size_t                                       batch_images) {
	if (batch_images == 0 || blocks_per_image == 0)
		throw std::invalid_argument("output completion requires nonzero batch and image geometry");
	const size_t                                      worksets = schedule.offsets.size() - 1U;
	std::vector<std::vector<JpegDctOutputReadyPoint>> result(worksets);
	std::vector<std::pair<size_t, uint64_t>> last(image_count / batch_images + (image_count % batch_images != 0),
	                                              {worksets, 0});
	const auto                               visit = [&](size_t w, uint64_t image, uint64_t task_end) {
        auto& point = last.at(image / batch_images);
        if (point.first == worksets || std::pair {w, task_end} > point)
            point = {w, task_end};
	};
	for (size_t w = 0; w < worksets; ++w) {
		if (!schedule.groups.empty()) {
			for (auto g = schedule.group_offsets[w]; g < schedule.group_offsets[w + 1]; ++g) {
				const auto& group = schedule.groups[g];
				if (group.image_count != 0) {
					for (uint64_t i = 0; i < group.image_count; ++i)
						visit(w,
						      schedule.image_indices[group.image_begin + i],
						      group.task_begin + (i + 1) * group.block_count);
				} else {
					for (uint64_t i = 0; i < group.block_count; ++i)
						visit(w,
						      schedule.active_output_blocks[group.block_begin + i] / blocks_per_image,
						      group.task_begin + i + 1);
				}
			}
		} else {
			const auto begin = schedule.offsets[w], end = schedule.offsets[w + 1];
			if (schedule.repeated_image_count > 1) {
				if (end != begin)
					for (uint64_t i = 0; i < schedule.repeated_image_count; ++i)
						visit(w, i, (i + 1) * (end - begin));
			} else {
				for (auto i = begin; i < end; ++i)
					visit(w, schedule.active_output_blocks[i] / blocks_per_image, i - begin + 1);
			}
		}
	}
	for (size_t batch = 0; batch < last.size(); ++batch) {
		const auto [w, task_end] = last[batch];
		if (w != worksets)
			result[w].push_back({task_end, batch});
	}
	for (auto& points : result)
		std::sort(points.begin(), points.end(), [](const auto& a, const auto& b) {
			return a.task_end < b.task_end || (a.task_end == b.task_end && a.output_batch < b.output_batch);
		});
	return result;
}
std::vector<std::vector<uint32_t>> expand(const JpegDctDeviceBlockMajorActiveOutputSchedule& s,uint64_t bpi){
 std::vector<std::vector<uint32_t>> x(s.offsets.size()-1);
 for(size_t w=0;w<x.size();++w){
  if(s.groups.empty()){
   for(uint32_t im=0;im<s.repeated_image_count;++im)
    for(auto k=s.offsets[w];k<s.offsets[w+1];++k)x[w].push_back(im*bpi+s.active_output_blocks[k]);
  } else {
   for(auto k=s.group_offsets[w];k<s.group_offsets[w+1];++k){
    const auto& g=s.groups[k];
    for(uint32_t im=0;im<std::max(g.image_count,1U);++im)
     for(uint32_t i=0;i<g.block_count;++i)x[w].push_back((g.image_count?s.image_indices[g.image_begin+im]*bpi:0)+s.active_output_blocks[g.block_begin+i]);
   }
  }
 }
 return x;
}
void check(const JpegDctDeviceBlockMajorActiveOutputSchedule& s,const JpegDctDeviceBlockMajorPlanlessPlan& p,const JpegDctGridTransformSpec& t){
 uint64_t y=uint64_t(t.y_output_width_blocks)*t.y_output_height_blocks,c=uint64_t(t.cbcr_output_width_blocks)*t.cbcr_output_height_blocks,bpi=y+2*c;
 auto x=expand(s,bpi);
 std::vector<std::set<uint32_t>> owners(s.logical_output_block_count);
 for(uint32_t w=0;w<x.size();++w){std::set<uint32_t> once;
  for(auto b:x[w]){assert(b<owners.size());assert(once.insert(b).second);owners[b].insert(w);}
 }
 auto got=build_split_down2_plan(s,p,t);size_t expected=0;std::set<uint32_t> slots;
 for(size_t b=0;b<owners.size();++b){auto local=b%bpi;auto comp=local<y?0U:1U+(local-y)/c;const auto& q=p.images[b/bpi].components[comp];
  bool down=q.present&&q.x_up_factor==1&&q.y_up_factor==1&&q.x_down_factor>=1&&q.y_down_factor>=1&&q.x_down_factor<=2&&q.y_down_factor<=2&&q.x_down_factor*q.y_down_factor>1;
  bool split=down&&owners[b].size()>1;expected+=split;
  if(!got.blocks.empty()){
   auto v=got.blocks[b];assert((v.slot!=UINT32_MAX)==split);
   if(split){assert(slots.insert(v.slot).second);assert(v.last_workset==*owners[b].rbegin());}
  }
 }
 assert((expected==0)==got.blocks.empty());assert(got.source_value_count==expected*256);
 if(!slots.empty()){assert(*slots.begin()==0);assert(*slots.rbegin()+1==expected);}
 for(size_t batch=1;batch<=p.images.size()+1;++batch){
  auto ready=build_output_batch_completion_schedule(s,bpi,p.images.size(),batch);
  std::vector<std::pair<size_t,uint64_t>> reference((p.images.size()+batch-1)/batch,{x.size(),0});
  for(size_t w=0;w<x.size();++w)for(size_t k=0;k<x[w].size();++k){size_t bi=x[w][k]/bpi/batch;reference[bi]={w,k+1};}
  std::vector<bool> seen(reference.size(),false);
  for(size_t w=0;w<ready.size();++w)for(auto r:ready[w]){assert(!seen[r.output_batch]);seen[r.output_batch]=true;assert(reference[r.output_batch]==std::make_pair(w,r.task_end));}
  for(size_t b=0;b<reference.size();++b)assert(seen[b]==(reference[b].first!=x.size()));
 }
}
constexpr float conv[128]={
0x1.6a09e40000000p-1F,   -0x1.8275a00000000p-26F, 0x1.44df280000000p-25F,  -0x1.5926600000000p-30F,
0x1.257d860000000p-26F,  -0x1.ee38c40000000p-24F, 0x1.0f04360000000p-26F,  -0x1.a7073e0000000p-26F,
0x1.6a09e40000000p-1F,   -0x1.8275a00000000p-26F, 0x1.44df280000000p-25F,  -0x1.5926600000000p-30F,
0x1.257d860000000p-26F,  -0x1.ee38c40000000p-24F, 0x1.0f04360000000p-26F,  -0x1.a7073e0000000p-26F,
0x1.4679360000000p-1F,   0x1.31ce1c0000000p-2F,   -0x1.df2c160000000p-5F,  0x1.8aa7d80000000p-6F,
-0x1.9957a00000000p-7F,  0x1.ceb2c40000000p-8F,   -0x1.0175300000000p-8F,  0x1.d142040000000p-10F,
-0x1.46793a0000000p-1F,  0x1.31ce200000000p-2F,   0x1.df2bf00000000p-5F,   0x1.8aa7e00000000p-6F,
0x1.9958020000000p-7F,   0x1.ceb5c80000000p-8F,   0x1.0173980000000p-8F,   0x1.d141dc0000000p-10F,
-0x1.374a980000000p-25F, 0x1.6a09e60000000p-1F,   -0x1.a67cdc0000000p-25F, 0x1.22314e0000000p-24F,
0x1.6ff0240000000p-25F,  0x1.52cd560000000p-24F,  -0x1.01c3ec0000000p-24F, 0x1.b2c7680000000p-24F,
0x1.5ba54c0000000p-24F,  -0x1.6a09e60000000p-1F,  0x1.133e6e0000000p-24F,  -0x1.22314e0000000p-24F,
-0x1.17f8120000000p-24F, -0x1.1966ac0000000p-23F, 0x1.e1c3ec0000000p-24F,  -0x1.658ed00000000p-25F,
-0x1.b8f24a0000000p-3F,  0x1.16da3a0000000p-1F,   0x1.865e1e0000000p-2F,   -0x1.856b020000000p-4F,
0x1.6580580000000p-5F,   -0x1.80b5d00000000p-6F,  0x1.a23c320000000p-7F,   -0x1.75c5ce0000000p-8F,
0x1.b8f2440000000p-3F,   0x1.16da3c0000000p-1F,   -0x1.865e1c0000000p-2F,  -0x1.856aec0000000p-4F,
-0x1.6580480000000p-5F,  -0x1.80b5c00000000p-6F,  -0x1.a23c0a0000000p-7F,  -0x1.75c3000000000p-8F,
0x1.f715080000000p-25F,  -0x1.12bf920000000p-24F, 0x1.6a09e80000000p-1F,   -0x1.be4b100000000p-28F,
-0x1.b54c3e0000000p-25F, -0x1.c3e49a0000000p-25F, 0x1.75639e0000000p-24F,  -0x1.a4625a0000000p-23F,
-0x1.91d5f00000000p-26F, -0x1.095fca0000000p-23F, 0x1.6a09e60000000p-1F,   0x1.48369e0000000p-25F,
0x1.cab3c20000000p-25F,  -0x1.c1f24c0000000p-24F, 0x1.c5639e0000000p-24F,  -0x1.32312c0000000p-22F,
0x1.0f88900000000p-3F,   -0x1.c677a60000000p-3F,  0x1.041f9a0000000p-1F,   0x1.9a63a80000000p-2F,
-0x1.b26d9c0000000p-4F,  0x1.9438ea0000000p-5F,   -0x1.9dc9fa0000000p-6F,  0x1.6814be0000000p-7F,
-0x1.0f8888000000p-3F,   -0x1.c677940000000p-3F,  -0x1.041f9e0000000p-1F,  0x1.9a63aa0000000p-2F,
0x1.b26d8c0000000p-4F,   0x1.94392e0000000p-5F,   0x1.9dca020000000p-6F,   0x1.6815fc0000000p-7F,
-0x1.2fa9760000000p-27F, 0x1.0330ea0000000p-24F, 0x1.c75c800000000p-33F,  0x1.6a09e60000000p-1F,
-0x1.d72bea0000000p-25F, 0x1.46d4d00000000p-24F,  -0x1.6c12680000000p-25F, 0x1.d4b4a00000000p-23F,
0x1.02fa980000000p-23F,  -0x1.9874e00000000p-31F, 0x1.9f8e280000000p-23F,  -0x1.6a09e60000000p-1F,
-0x1.146a0c0000000p-24F, 0x1.192b300000000p-24F,  -0x1.cfb6640000000p-27F, -0x1.ecb4a00000000p-23F,
-0x1.9388f00000000p-4F,  0x1.3517200000000p-3F,   -0x1.9e6c920000000p-3F,  0x1.fcfe940000000p-2F,
0x1.a03ac20000000p-2F,   -0x1.b9b2840000000p-4F,  0x1.85af280000000p-5F,   -0x1.4059020000000p-6F,
0x1.9388dc0000000p-4F,   0x1.3517400000000p-3F,   0x1.9e6c740000000p-3F,   0x1.fcfeb0000000p-2F,
-0x1.a03aae0000000p-2F,  -0x1.b9b28c0000000p-4F,  -0x1.85aede0000000p-5F,  -0x1.4057cc0000000p-6F,

};
std::array<float,64> transform(const std::array<float,256>& a,uint32_t xd=2,uint32_t yd=2){
 std::array<float,128> v{};std::array<float,64> z{};const auto width=xd*8;
 for(uint32_t y=0;y<8;++y)for(uint32_t x=0;x<width;++x){float sum=0;
  if(yd==1)sum=a[y*width+x];else for(uint32_t i=0;i<16;++i)sum=std::fma(conv[y*16+i],a[i*width+x],sum);
  v[y*width+x]=sum;
 }
 for(uint32_t y=0;y<8;++y)for(uint32_t x=0;x<8;++x){float sum=0;
  if(xd==1)sum=v[y*width+x];else for(uint32_t i=0;i<16;++i)sum=std::fma(v[y*width+i],conv[x*16+i],sum);
  z[y*8+x]=xd*yd==4?sum*0.5F:xd*yd==2?sum/0x1.6a09e60000000p+0F:sum;
 }
 return z;
}
int main(){
 std::cout.precision(17);
 std::mt19937 rng(20261010);size_t cases=0;
 for(int mode=0;mode<3;++mode)for(int trial=0;trial<400;++trial){
  uint32_t n=1+rng()%8,nw=1+rng()%8;JpegDctGridTransformSpec t;t.y_output_width_blocks=1+rng()%5;t.y_output_height_blocks=1+rng()%3;t.cbcr_output_width_blocks=1+rng()%3;
  uint64_t bpi=t.y_output_width_blocks*t.y_output_height_blocks+2*t.cbcr_output_width_blocks*t.cbcr_output_height_blocks;
  JpegDctDeviceBlockMajorPlanlessPlan p;p.images.resize(n);
  for(auto& im:p.images)for(auto& c:im.components){auto k=rng()%5;c.present=k!=0;c.x_up_factor=k==1?2:1;c.x_down_factor=k==2?1:2;c.y_down_factor=k==3?1:2;}
  JpegDctDeviceBlockMajorActiveOutputSchedule s;s.logical_output_block_count=n*bpi;s.offsets={0};
  if(mode==0){ // Absolute slices.
   for(uint32_t w=0;w<nw;++w){for(uint32_t b=0;b<n*bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(b);s.offsets.push_back(s.active_output_blocks.size());}
  }else if(mode==1){ // Shared relative slices with repeated occurrences.
   s.repeated_image_count=n;
   for(uint32_t w=0;w<nw;++w){for(uint32_t b=0;b<bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(b);s.offsets.push_back(s.active_output_blocks.size());}
  }else{ // Groups alternate absolute and relative subsets, shuffled occurrence order.
   s.group_offsets={0};
   for(uint32_t w=0;w<nw;++w){std::vector<uint32_t> ids(n);for(uint32_t j=0;j<n;++j)ids[j]=j;std::shuffle(ids.begin(),ids.end(),rng);uint64_t task=0;
    for(uint32_t start=0;start<n;){uint32_t count=1+rng()%(n-start);bool relative=(rng()%2)!=0;uint64_t begin=s.active_output_blocks.size();uint32_t image_begin=s.image_indices.size();
     if(relative){for(uint32_t b=0;b<bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(b);for(uint32_t j=0;j<count;++j)s.image_indices.push_back(ids[start+j]);}
     else {for(uint32_t j=0;j<count;++j)for(uint32_t b=0;b<bpi;++b)if(rng()%3==0)s.active_output_blocks.push_back(ids[start+j]*bpi+b);}
     uint32_t block_count=s.active_output_blocks.size()-begin;if(block_count)s.groups.push_back({begin,block_count,image_begin,relative?count:0,task});task+=uint64_t(block_count)*(relative?count:1);start+=count;
    }
    s.group_offsets.push_back(s.groups.size());s.offsets.push_back(s.active_output_blocks.size());
   }
  }
  check(s,p,t);++cases;
 }
 // Emulate gather ownership and the published scalar FP32 FMA pass order.
 size_t algebra_cases=0,gather_equal=0,old_integer_mismatch=0;float max_old_float_error=0;bool have_example=false;
 float example_full=0,example_old=0;
 for(uint32_t xd=1;xd<=2;++xd)for(uint32_t yd=1;yd<=2;++yd)if(xd*yd>1)for(int trial=0;trial<501;++trial){
  std::array<float,256> src{},saved{},parts[4]{};
  for(uint32_t y=0;y<yd*8;++y)for(uint32_t x=0;x<xd*8;++x){size_t i=y*(xd*8)+x;src[i]=float(int(rng()%101)-50);parts[(y/8)*xd+x/8][i]=src[i];}
  auto full=transform(src,xd,yd);std::array<float,64> old{};
  for(uint32_t w=0;w<xd*yd;++w){auto partial=transform(parts[w],xd,yd);for(int i=0;i<64;++i)old[i]+=partial[i];for(uint32_t y=0;y<yd*8;++y)for(uint32_t x=0;x<xd*8;++x)if((y/8)*xd+x/8==w)saved[y*(xd*8)+x]=src[y*(xd*8)+x];}
  auto after=transform(saved,xd,yd);assert(std::memcmp(after.data(),full.data(),sizeof(after))==0);++gather_equal;++algebra_cases;
  for(int i=0;i<64;++i){max_old_float_error=std::max(max_old_float_error,std::abs(old[i]-full[i]));if(std::nearbyint(old[i])!=std::nearbyint(full[i])){++old_integer_mismatch;if(!have_example){have_example=true;example_full=full[i];example_old=old[i];}}}
 }
 // Padding with a legal positive-only clamp exposes the zero-initialization boundary.
 std::array<float,256> padded_reference{},padded_saved{};
 for(size_t y=0;y<16;++y)for(size_t x=0;x<16;++x){size_t i=y*16+x;bool in_bounds=x<8;padded_reference[i]=in_bounds?float(10+(i%3)):10.0F;padded_saved[i]=in_bounds?padded_reference[i]:0.0F;}
 auto padded_expected=transform(padded_reference),padded_actual=transform(padded_saved);size_t padding_different=0;
 for(int i=0;i<64;++i)padding_different+=std::nearbyint(padded_expected[i])!=std::nearbyint(padded_actual[i]);
 // Actual compact planning sorts descriptors physically but preserves their
 // original request_index. The completion function only sees descriptor IDs.
 JpegDctDeviceBlockMajorActiveOutputSchedule inverse;
 inverse.offsets={0,4,8};inverse.active_output_blocks={0,1,2,3,4,5,6,7};inverse.logical_output_block_count=8;
 auto wrong_ready=build_output_batch_completion_schedule(inverse,4,2,1);
 size_t reported_output0_workset=99;
 for(size_t w=0;w<wrong_ready.size();++w)for(auto point:wrong_ready[w])if(point.output_batch==0)reported_output0_workset=w;
 // Descriptor 0 has request_index=1; descriptor 1 has request_index=0.
 size_t actual_output0_last_writer_workset=1;
 assert(reported_output0_workset==0);
 std::cout<<"{\"planner_cases\":"<<cases<<",\"completion_checked_with_multiple_batch_sizes_for_identity_request_mapping\":true,\"cpu_algebra_cases\":"<<algebra_cases<<",\"gather_equal\":"<<gather_equal<<",\"old_partial_integer_mismatches\":"<<old_integer_mismatch<<",\"max_old_float_error\":"<<max_old_float_error<<",\"example_full\":"<<example_full<<",\"example_old\":"<<example_old<<",\"positive_only_clamp_padding_different\":"<<padding_different<<",\"inverse_request_reported_output0_ready_workset\":"<<reported_output0_workset<<",\"inverse_request_actual_output0_last_writer_workset\":"<<actual_output0_last_writer_workset<<"}\n";
}
