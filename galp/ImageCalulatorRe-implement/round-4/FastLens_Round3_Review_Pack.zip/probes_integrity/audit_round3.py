"""Read-only audit of supplied Round-3 bytes, references, traces and declarations.

No Torch/GPU, original JPEG, native binary, or missing NPZ payload is executed or
verified here. Original artifact JSON bytes are never rebased or rewritten.
"""
from pathlib import Path
import ast
import collections
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "submission"
CODE = ROOT / "current_repo"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def resolve(path):
    for prefix, destination in (
        ("/home/tangyuxin/gfastlanes/FastLanes/", CODE),
        ("/home/tangyuxin/RGB-no-more/", ROOT / "external/RGB-no-more"),
        ("/home/tangyuxin/tmp/dct-round3-prod-h100-20261010-012949/", ROOT / "evidence/prepared"),
        ("/home/tangyuxin/tmp/dct-round3-fixed-20261010-173729/", ROOT / "evidence/h100_first_four"),
        ("/home/tangyuxin/tmp/dct-round3-fs-h100-20261011-002802/", ROOT / "evidence/h100_fs_retry"),
    ):
        if path.startswith(prefix):
            target = destination / path[len(prefix):]
            return target if target.is_relative_to(destination) else None
    return None


def refs(value):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str):
            for hash_key in ("sha256", "jpeg_sha256"):
                if hash_key in value:
                    yield value["path"], value[hash_key]
        for child in value.values():
            if isinstance(child, (dict, list)):
                yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            if isinstance(child, (dict, list)):
                yield from refs(child)


def main():
    record_paths = sorted(p for p in (ROOT / "evidence").rglob("*.json")
                          if p.name.endswith((".calibration.json", ".verified.json")))
    records, reference_inventory, hash_cache = [], {}, {}
    reference_occurrences = collections.Counter()

    def inspect_ref(original, expected):
        key = original, expected
        reference_occurrences[key] += 1
        if key not in reference_inventory:
            path = resolve(original)
            if path is None or not path.is_file():
                status, actual = "not_bundled", None
            else:
                if path not in hash_cache:
                    hash_cache[path] = sha(path)
                actual = hash_cache[path]
                status = "match" if actual == expected else "different_current_bytes"
            reference_inventory[key] = dict(original_path=original,
                local_path=str(path.relative_to(ROOT)) if path else None,
                expected_sha256=expected, actual_sha256=actual, status=status)
        return reference_inventory[key]

    for path in record_paths:
        value = json.loads(path.read_text())
        implementation = [inspect_ref(v["path"], v["sha256"]) for v in value["implementation"]]
        records.append(dict(file=str(path.relative_to(ROOT)), backend=value["backend"]["kind"],
            phase=value["phase"], status=value["status"], updates=value["updates"],
            samples_per_update=[v["samples"] for v in value["training"]],
            microbatches_per_update=[len(v["losses"]) for v in value["training"]],
            occurrences=value["occurrence_count"], unique_images=value["unique_image_count"],
            maximum_errors=value["max_abs_errors"], tolerance=value["tolerance"],
            runtime=value["runtime"], headline_eligible=value["headline_eligible"],
            snapshot=value["snapshot"], initial_model_sha256=value["initial_model_sha256"],
            declared_backend_artifacts=value["backend"],
            implementation_matches=sum(v["status"] == "match" for v in implementation),
            implementation_differences=[v for v in implementation if v["status"] != "match"]))
        for original, expected in refs({k: v for k, v in value.items() if k != "implementation"}):
            inspect_ref(original, expected)

    core = ROOT / "evidence/prepared"
    config = json.loads((core / "contract/matched.json").read_text())
    profile = json.loads((core / "contract/profile.json").read_text())
    labels = json.loads((core / "contract/labels.json").read_text())["labels"]
    source = json.loads((core / "contract/source.json").read_text())
    recipe = json.loads((core / "source_recipe.json").read_text())
    for value in (config, profile, source, recipe):
        for original, expected in refs(value):
            inspect_ref(original, expected)
    source_images = {v["image_id"]: v for v in source["images"]}
    producer_images = {v["image_id"]: v for v in recipe["inputs"]}
    producer_source_agreement = set(source_images) == set(producer_images) and all(
        row["jpeg_sha256"] == producer_images[key]["jpeg"]["sha256"] for key, row in source_images.items())

    stores = []
    for path in sorted(core.glob("*/store.json")):
        value = json.loads(path.read_text())
        for original, expected in refs(value):
            inspect_ref(original, expected)
        declared = value["content_fingerprint"]
        identity = {k: v for k, v in value.items()
                    if k not in ("content_fingerprint", "conversion_wall_s", "conversion_cpu_s")}
        computed = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        metadata_match = len(value["images"]) == len(source_images)
        for item in value["images"]:
            expected = {k: v for k, v in source_images[item["metadata"]["image_id"]].items()
                        if k != "quantization_tables"}
            metadata_match &= item["metadata"] == expected
        stores.append(dict(file=str(path.relative_to(ROOT)), method=value["method"],
            images=len(value["images"]), storage_group_images=value["storage_group_images"],
            groups=len(value["groups"]), manifest_fingerprint_match=declared == computed,
            image_metadata_matches_source=metadata_match,
            payload_file_count=len(value["files"]),
            payload_files_available=sum((path.parent / name).is_file() for name in value["files"]),
            payload_bytes_declared=sum(v["size_bytes"] for v in value["files"].values()),
            all_source_frequencies=all(v["masks"] == [list(range(64))] * 3 for v in value["images"])))
        del value

    training_path = CODE / "galp/benchmarks/dct_baselines/training.py"
    tree = ast.parse(training_path.read_text())
    namespace = {}
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef)
                                 and n.name == "update_windows"], type_ignores=[]),
                 str(training_path), "exec"), namespace)
    traces, ids = [], []
    for filename in ("calibration_trace.jsonl", "trace.jsonl"):
        rows = [json.loads(line) for line in (core / "contract" / filename).read_text().splitlines() if line]
        windows = namespace["update_windows"](rows, config["training"]["accumulation"])
        ids.append({v["image_id"] for v in rows})
        batches = collections.Counter(v["microbatch_id"] for v in rows)
        traces.append(dict(file=filename, occurrences=len(rows), unique_images=len(ids[-1]),
            unique_occurrences=len({v["occurrence_id"] for v in rows}),
            updates=len(windows), samples_per_update=[len(w) for w in windows],
            microbatches_per_update=[len({v["microbatch_id"] for v in w}) for w in windows],
            microbatch_size_histogram=dict(collections.Counter(batches.values())),
            all_labels_match=all(v["target_label"] == labels[v["image_id"]] == source_images[v["image_id"]]["label"]
                                 for v in rows),
            all_images_in_source=set(ids[-1]) <= set(source_images)))

    reference_records = []
    for key, record in reference_inventory.items():
        reference_records.append(dict(record, occurrences=reference_occurrences[key]))
    summary = dict(
        scope="Local source/hash/declaration/trace audit only; no GPU, model, binary, original JPEG or missing NPZ payload verification.",
        record_count=len(records), verification_count=sum(v["phase"] == "verification" for v in records),
        calibration_count=sum(v["phase"] == "calibration" for v in records),
        recorded_passes=sum(v["status"] == "passed" for v in records),
        baseline_module_comparisons=sum(len(v["implementation_differences"]) + v["implementation_matches"] for v in records),
        baseline_module_matches=sum(v["implementation_matches"] for v in records),
        baseline_module_differences=sum(len(v["implementation_differences"]) for v in records),
        unique_reference_status_counts=dict(collections.Counter(v["status"] for v in reference_records)),
        different_current_references=[v for v in reference_records if v["status"] == "different_current_bytes"],
        source_images=len(source_images), producer_checked_images=recipe["checked_images"],
        producer_declared_scope=recipe["scope"], producer_source_sha_declarations_match=producer_source_agreement,
        trace_overlap=len(ids[0] & ids[1]), trace_union_covers_source=(ids[0] | ids[1]) == set(source_images),
        initialization=config["training"]["initialization"], model=profile["model"],
        training_numerical_fixture_only=config["training"].get("numerical_fixture_only"),
        unique_snapshot_hashes=len({v["snapshot"]["sha256"] for v in records}),
        unique_initial_model_hashes=len({v["initial_model_sha256"] for v in records}),
        all_errors_zero=all(all(n == 0 for n in v["maximum_errors"].values()) for v in records),
        all_headline_ineligible=all(not v["headline_eligible"] for v in records),
        store_payloads_available=sum(v["payload_files_available"] for v in stores),
        store_payloads_declared=sum(v["payload_file_count"] for v in stores))
    output = dict(summary=summary, records=records, traces=traces, stores=stores,
                  configuration=config, source_recipe_summary={k: v for k, v in recipe.items() if k != "inputs"},
                  references=reference_records)
    (HERE / "results.json").write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(dict(summary=summary, traces=traces, stores=stores), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
